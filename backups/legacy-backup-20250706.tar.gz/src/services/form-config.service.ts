/**
 * Form Configuration Service
 * 
 * Handles all API communication for dynamic form configurations
 */

import { supabase } from '@/integrations/supabase/client';
import type {
  FormConfiguration,
  FormConfigurationRecord,
  FormConfigResponse,
  ValidationResponse,
  SecurityValidationResult,
  DeploymentOptions,
  FormUsageAnalytics
} from '@/types/dynamic-forms';

export class FormConfigService {
  /**
   * Create a new form configuration
   */
  static async createConfiguration(
    formData: FormConfiguration
  ): Promise<FormConfigResponse> {
    try {
      const { data, error } = await supabase.functions.invoke('form-config-manager', {
        body: {
          action: 'create',
          formData
        }
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Failed to create form configuration:', error);
      throw new Error(`Failed to create form configuration: ${error.message}`);
    }
  }

  /**
   * Update an existing form configuration
   */
  static async updateConfiguration(
    configId: string,
    formData: FormConfiguration
  ): Promise<FormConfigResponse> {
    try {
      const { data, error } = await supabase.functions.invoke('form-config-manager', {
        body: {
          action: 'update',
          configId,
          formData
        }
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Failed to update form configuration:', error);
      throw new Error(`Failed to update form configuration: ${error.message}`);
    }
  }

  /**
   * Get a form configuration by ID
   */
  static async getConfiguration(configId: string): Promise<FormConfigResponse> {
    try {
      const { data, error } = await supabase.functions.invoke('form-config-manager', {
        method: 'GET',
        body: {
          action: 'get',
          configId
        }
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Failed to get form configuration:', error);
      throw new Error(`Failed to get form configuration: ${error.message}`);
    }
  }

  /**
   * Get a form configuration by name (active deployment)
   */
  static async getConfigurationByName(configName: string): Promise<FormConfigResponse> {
    try {
      const { data, error } = await supabase.functions.invoke('form-config-manager', {
        method: 'GET',
        body: {
          action: 'get',
          configName
        }
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Failed to get form configuration by name:', error);
      throw new Error(`Failed to get form configuration by name: ${error.message}`);
    }
  }

  /**
   * List all form configurations
   */
  static async listConfigurations(): Promise<{
    success: boolean;
    data?: { configurations: FormConfigurationRecord[] };
    error?: any;
  }> {
    try {
      const { data, error } = await supabase.functions.invoke('form-config-manager', {
        method: 'GET',
        body: {
          action: 'list'
        }
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Failed to list form configurations:', error);
      throw new Error(`Failed to list form configurations: ${error.message}`);
    }
  }

  /**
   * Delete (archive) a form configuration
   */
  static async deleteConfiguration(configId: string): Promise<{ success: boolean; message?: string; error?: any }> {
    try {
      const { data, error } = await supabase.functions.invoke('form-config-manager', {
        body: {
          action: 'delete',
          configId
        }
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Failed to delete form configuration:', error);
      throw new Error(`Failed to delete form configuration: ${error.message}`);
    }
  }

  /**
   * Deploy a form configuration
   */
  static async deployConfiguration(
    configId: string,
    deploymentOptions?: DeploymentOptions
  ): Promise<FormConfigResponse> {
    try {
      const { data, error } = await supabase.functions.invoke('form-config-manager', {
        body: {
          action: 'deploy',
          configId,
          deploymentOptions
        }
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Failed to deploy form configuration:', error);
      throw new Error(`Failed to deploy form configuration: ${error.message}`);
    }
  }

  /**
   * Validate a form configuration
   */
  static async validateConfiguration(
    config: FormConfiguration,
    validationLevel: 'basic' | 'security' | 'comprehensive' = 'security',
    includePerformanceMetrics: boolean = false
  ): Promise<ValidationResponse> {
    try {
      const { data, error } = await supabase.functions.invoke('form-schema-validator', {
        body: {
          config,
          validationLevel,
          includePerformanceMetrics
        }
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Failed to validate form configuration:', error);
      throw new Error(`Failed to validate form configuration: ${error.message}`);
    }
  }

  /**
   * Log form usage analytics
   */
  static async logUsageAnalytics(
    configId: string,
    eventType: 'view' | 'interaction' | 'submit' | 'error' | 'abandon',
    eventData?: {
      fieldId?: string;
      sessionId?: string;
      eventData?: any;
      loadTimeMs?: number;
      interactionTimeMs?: number;
    }
  ): Promise<void> {
    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      
      // Use the database function to log analytics
      const { error } = await supabase.rpc('log_form_usage', {
        p_config_id: configId,
        p_user_id: user?.id || null,
        p_session_id: eventData?.sessionId || this.getSessionId(),
        p_event_type: eventType,
        p_field_id: eventData?.fieldId || null,
        p_event_data: eventData?.eventData || {},
        p_load_time_ms: eventData?.loadTimeMs || null,
        p_ip_address: null, // Will be populated server-side
        p_user_agent: navigator.userAgent
      });

      if (error) {
        console.warn('Failed to log form usage analytics:', error);
        // Don't throw error for analytics failures
      }
    } catch (error) {
      console.warn('Failed to log form usage analytics:', error);
      // Don't throw error for analytics failures
    }
  }

  /**
   * Get or create a session ID for analytics tracking
   */
  private static getSessionId(): string {
    const sessionKey = 'parker-flight-session-id';
    let sessionId = sessionStorage.getItem(sessionKey);
    
    if (!sessionId) {
      sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      sessionStorage.setItem(sessionKey, sessionId);
    }
    
    return sessionId;
  }

  /**
   * Get form analytics data
   */
  static async getFormAnalytics(
    configId: string,
    timeRange: '24h' | '7d' | '30d' = '7d'
  ): Promise<{
    totalViews: number;
    completionRate: number;
    errorRate: number;
    fieldInteractions: any[];
  }> {
    try {
      const { data, error } = await supabase.functions.invoke('get-form-analytics', {
        body: { configId, timeRange }
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Failed to get form analytics:', error);
      throw new Error(`Failed to get form analytics: ${error.message}`);
    }
  }

  /**
   * Export form configuration
   */
  static async exportConfiguration(configId: string): Promise<FormConfiguration> {
    try {
      const response = await this.getConfiguration(configId);
      
      if (!response.success || !response.data) {
        throw new Error('Failed to export configuration');
      }

      return response.data.config.config_data;
    } catch (error) {
      console.error('Failed to export form configuration:', error);
      throw new Error(`Failed to export form configuration: ${error.message}`);
    }
  }

  /**
   * Import form configuration
   */
  static async importConfiguration(
    name: string,
    configuration: FormConfiguration
  ): Promise<FormConfigResponse> {
    try {
      // Create a new configuration with imported data
      const importedConfig: FormConfiguration = {
        ...configuration,
        id: crypto.randomUUID(),
        name,
        version: 1,
        metadata: {
          ...configuration.metadata,
          imported: true,
          importedAt: new Date().toISOString(),
          originalId: configuration.id
        }
      };

      return await this.createConfiguration(importedConfig);
    } catch (error) {
      console.error('Failed to import form configuration:', error);
      throw new Error(`Failed to import form configuration: ${error.message}`);
    }
  }

  /**
   * Clone a form configuration
   */
  static async cloneConfiguration(
    configId: string,
    newName: string
  ): Promise<FormConfigResponse> {
    try {
      const original = await this.getConfiguration(configId);
      
      if (!original.success || !original.data) {
        throw new Error('Failed to get original configuration');
      }

      const clonedConfig: FormConfiguration = {
        ...original.data.config.config_data,
        id: crypto.randomUUID(),
        name: newName,
        version: 1,
        metadata: {
          ...original.data.config.config_data.metadata,
          cloned: true,
          clonedAt: new Date().toISOString(),
          originalId: configId
        }
      };

      return await this.createConfiguration(clonedConfig);
    } catch (error) {
      console.error('Failed to clone form configuration:', error);
      throw new Error(`Failed to clone form configuration: ${error.message}`);
    }
  }

  /**
   * Get form configuration versions
   */
  static async getConfigurationVersions(name: string): Promise<FormConfigurationRecord[]> {
    try {
      const { data, error } = await supabase
        .from('form_configurations')
        .select('*')
        .eq('name', name)
        .order('version', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Failed to get configuration versions:', error);
      throw new Error(`Failed to get configuration versions: ${error.message}`);
    }
  }

  /**
   * Rollback to a previous version
   */
  static async rollbackToVersion(
    name: string,
    version: number,
    deploymentOptions?: DeploymentOptions
  ): Promise<FormConfigResponse> {
    try {
      const versions = await this.getConfigurationVersions(name);
      const targetVersion = versions.find(v => v.version === version);
      
      if (!targetVersion) {
        throw new Error(`Version ${version} not found for form ${name}`);
      }

      // Create a new version based on the target version
      const rollbackConfig: FormConfiguration = {
        ...targetVersion.config_data,
        id: crypto.randomUUID(),
        version: Math.max(...versions.map(v => v.version)) + 1,
        metadata: {
          ...targetVersion.config_data.metadata,
          rollback: true,
          rollbackAt: new Date().toISOString(),
          rollbackFromVersion: version
        }
      };

      const created = await this.createConfiguration(rollbackConfig);
      
      if (created.success && created.data) {
        // Deploy the rollback version if deployment options provided
        if (deploymentOptions) {
          return await this.deployConfiguration(created.data.config.id, deploymentOptions);
        }
      }

      return created;
    } catch (error) {
      console.error('Failed to rollback configuration:', error);
      throw new Error(`Failed to rollback configuration: ${error.message}`);
    }
  }
}

// Export a default instance for convenience
export const formConfigService = FormConfigService;
