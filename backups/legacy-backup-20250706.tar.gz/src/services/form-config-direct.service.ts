/**
 * Direct Form Configuration Service
 * 
 * Simple service that reads directly from database for immediate testing
 * TODO: Replace with Edge Functions in Phase 3
 */

import { supabase } from '@/integrations/supabase/client';
import type {
  FormConfiguration,
  FormConfigurationRecord,
  FormConfigResponse
} from '@/types/dynamic-forms';

export class FormConfigDirectService {
  /**
   * Get a form configuration by name (active deployment)
   */
  static async getConfigurationByName(configName: string): Promise<FormConfiguration | null> {
    try {
      const { data, error } = await supabase
        .from('form_configurations')
        .select('*')
        .eq('name', configName)
        .eq('status', 'deployed')
        .order('deployed_at', { ascending: false })
        .limit(1)
        .single();

      if (error) {
        console.error('Failed to get form configuration by name:', error);
        return null;
      }

      if (!data) {
        return null;
      }

      // Return the config_data as FormConfiguration
      return data.config_data as FormConfiguration;
    } catch (error) {
      console.error('Failed to get form configuration by name:', error);
      return null;
    }
  }

  /**
   * Get a form configuration by ID
   */
  static async getConfiguration(configId: string): Promise<FormConfiguration | null> {
    try {
      const { data, error } = await supabase
        .from('form_configurations')
        .select('*')
        .eq('id', configId)
        .single();

      if (error) {
        console.error('Failed to get form configuration:', error);
        return null;
      }

      if (!data) {
        return null;
      }

      return data.config_data as FormConfiguration;
    } catch (error) {
      console.error('Failed to get form configuration:', error);
      return null;
    }
  }

  /**
   * List all deployed form configurations
   */
  static async listConfigurations(): Promise<FormConfigurationRecord[]> {
    try {
      const { data, error } = await supabase
        .from('form_configurations')
        .select('*')
        .eq('status', 'deployed')
        .order('deployed_at', { ascending: false });

      if (error) {
        console.error('Failed to list form configurations:', error);
        return [];
      }

      return data || [];
    } catch (error) {
      console.error('Failed to list form configurations:', error);
      return [];
    }
  }

  /**
   * Save/Update a form configuration
   */
  static async saveConfiguration(config: FormConfiguration): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('form_configurations')
        .upsert({
          name: config.name,
          version: config.version || 1,
          status: 'draft',
          config_data: config,
          validation_schema: {}, // TODO: Generate from config
          ui_schema: {}
        });

      if (error) {
        console.error('Failed to save form configuration:', error);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Failed to save form configuration:', error);
      return false;
    }
  }
}
