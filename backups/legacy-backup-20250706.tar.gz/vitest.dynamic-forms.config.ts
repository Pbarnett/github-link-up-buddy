/**
 * Vitest Configuration for Dynamic Forms
 * 
 * Specialized test configuration for dynamic forms system
 * Includes performance benchmarks, integration tests, and accessibility testing
 */

import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react-swc';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  test: {
    name: 'dynamic-forms',
    environment: 'jsdom',
    setupFiles: [
      './src/tests/setup-dynamic-forms.ts'
    ],
    include: [
      // Component tests
      'src/components/forms/**/*.{test,spec}.{js,mjs,cjs,ts,mts,cts,jsx,tsx}',
      // Hook tests
      'src/hooks/{useFormConfiguration,useFormState,useConditionalLogic,useFormValidation,useDynamicForm}.{test,spec}.{js,mjs,cjs,ts,mts,cts,jsx,tsx}',
      // Service tests
      'src/services/form-config.service.{test,spec}.{js,mjs,cjs,ts,mts,cts,jsx,tsx}',
      // Store tests
      'src/stores/useFormStore.{test,spec}.{js,mjs,cjs,ts,mts,cts,jsx,tsx}',
      // Utility tests
      'src/lib/{form-validation,conditional-logic}.{test,spec}.{js,mjs,cjs,ts,mts,cts,jsx,tsx}',
      // Integration tests
      'src/tests/integration/**/*.{test,spec}.{js,mjs,cjs,ts,mts,cts,jsx,tsx}',
      // Performance tests
      'src/tests/performance/**/*.{test,spec}.{js,mjs,cjs,ts,mts,cts,jsx,tsx}'
    ],
    exclude: [
      '**/node_modules/**',
      '**/dist/**',
      '**/.{idea,git,cache,output,temp}/**'
    ],
    globals: true,
    testTimeout: 10000,
    hookTimeout: 10000,
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html', 'lcov'],
      exclude: [
        'coverage/**',
        'dist/**',
        '**/node_modules/**',
        '**/*.d.ts',
        'src/tests/**',
        'scripts/**',
        'docs/**'
      ],
      thresholds: {
        lines: 85,
        functions: 80,
        branches: 75,
        statements: 85
      }
    }
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src')
    }
  }
});
