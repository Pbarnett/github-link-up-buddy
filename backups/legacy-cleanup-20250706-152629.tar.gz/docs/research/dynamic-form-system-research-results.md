# Dynamic Form Configuration System - Research Results

*This document contains the research findings and recommendations from external LLM analysis based on the brief in `dynamic-form-system-brief.md`*

---

## Research Results

Config-Driven Dynamic Form Architecture for Parker Flight
Parker Flight requires a highly flexible form system to rapidly adjust flight search and booking forms without code deployments. Below we propose a production-grade, configuration-driven form architecture spanning frontend and backend, with strong security, performance, and extensibility. Inspired by dynamic UIs in Google Flights (fast, interactive filters), Stripe’s Dashboard (robust form handling), and Retool (configurable interfaces), this solution enables non-developers to modify forms via config while maintaining type-safe validation, accessibility (WCAG 2.1 AA), and mobile-first responsive design.
Frontend Architecture
Dynamic Form Rendering from Configuration
Use a JSON-based schema or config object to declaratively define form fields, steps, and behavior. The form UI will be rendered by looping over this config rather than hard-coded fields. This approach provides flexibility to add/remove fields or change labels and options without touching React code
medium.com
medium.com
. By iterating through the schema and using a component map, the app can dynamically render form controls based on their defined types, eliminating repetitive JSX and improving maintainability
medium.com
. Each field definition in the config can include properties like id, label, type (e.g. text, select, date, etc.), UI props (placeholder, options for selects, etc.), and validation rules. A simple example schema might be:
ts
Copy
// Example form config schema (simplified)
interface FormConfig { id: string; title: string; fields: FieldConfig[]; }
type FieldType = 'text' | 'email' | 'number' | 'select' | 'checkbox' | 'date';
interface FieldConfig {
  id: string;
  label: string;
  type: FieldType;
  required?: boolean;
  options?: string[];              // for select/radio fields
  validation?: {                   // validation rules (min, max, pattern, etc.)
    minLength?: number;
    maxLength?: number;
    pattern?: RegExp;
    customError?: string;
  };
  conditional?: {                  // optional display condition
    fieldId: string;               // another field to watch
    equals: any;                   // value that triggers display
  };
}
A React form renderer component will iterate formConfig.fields and for each field render the appropriate input component. A component map (or switch-case) can map field.type to a React component (using Tailwind + shadcn/ui components, see below). For example:
jsx
Copy
{formConfig.fields.map(field => {
  switch(field.type) {
    case 'text':
    case 'email':
    case 'number':
      return (
        <FormField key={field.id} name={field.id}>
          <FormLabel>{field.label}</FormLabel>
          <FormControl>
            <Input type={field.type} placeholder={field.label} {...register(field.id, {/* rules */})} />
          </FormControl>
          <FormMessage />
        </FormField>
      );
    case 'select':
      return (
        <FormField key={field.id} name={field.id}>
          <FormLabel>{field.label}</FormLabel>
          <FormControl>
            <Select {...register(field.id)}>
              {field.options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </Select>
          </FormControl>
          <FormMessage />
        </FormField>
      );
    // ... other field types
  }
})}
This pseudo-code uses a <FormField> wrapper (from shadcn/ui) to ensure consistent layout, labeling, and error display. The dynamic renderer ensures fast updates: changing the JSON config (e.g. adding a field) immediately reflects in the UI without a redeploy
reddit.com
. Parker Flight’s forms (e.g. flight search filters) can thus be adjusted by editing config stored in the database, and the React app will automatically render the new fields (“Dynamic Adjustments: update the form in real-time as the schema changes.”
reddit.com
). We recommend a custom JSON schema format (as sketched above) tailored to Parker’s needs (rather than a verbose generic JSON Schema standard) for simplicity and to minimize bundle size. This schema can be versioned and stored in Supabase (described later). Avoiding heavy libraries (e.g. comprehensive form generators) keeps the bundle impact low (<50KB target). The dynamic renderer logic itself can be a lightweight utility. If needed, you could evaluate existing solutions like react-jsonschema-form, but those might add bloat; a focused in-house implementation using React Hook Form is likely more performant and bundle-efficient.
Validation with Zod and TypeScript Type Safety
To maintain robust validation and type safety, use Zod schemas generated from the form config. Parker’s stack already uses Zod and React Hook Form (RHF), which integrate via zodResolver for schema validation. We can write a utility that converts the JSON field definitions into a Zod object schema at runtime. For example, a text field with required:true and maxLength: 20 becomes z.string().min(1, "Required").max(20, "Too long"), an email field adds .email(), a number field might use z.number() with min/max, etc. All these can be derived from the config’s validation rules. This dynamic Zod schema can then be used in useForm:
ts
Copy
const zodSchema = buildZodSchema(formConfig);  // custom function to build schema
const form = useForm<z.infer<typeof zodSchema>>({
  resolver: zodResolver(zodSchema),
  defaultValues: ... 
});
React Hook Form will then enforce validation using Zod, preserving the same error messages defined in config. This approach means that even though the form fields are dynamic, they still benefit from schema-defined validation rules and clear errors. It also ensures any data submitted can be validated against the Zod schema on both client and server for consistency. While full compile-time type inference for dynamic forms is tricky (since the fields aren’t known ahead of time), we maintain type safety by strictly typing the config schema itself and using Zod for runtime checks. The config format (e.g. the FieldConfig interface) is defined in TypeScript so that any config JSON can be validated when loading (using Zod or TypeScript parsing) – catching configuration errors early. At runtime, z.infer<typeof zodSchema> gives us a TypeScript type for the form values that can be used in handler functions (though this is a generic object with string keys in dynamic scenarios). The key is that Zod provides runtime guarantees that the data conforms to the expected types/rules. React Hook Form natively supports integrating such validation rules from a schema
medium.com
 – it will automatically display errors as defined by the schema rules
medium.com
. In summary, the dynamic form can “integrate validation rules in the JSON schema” so that RHF + Zod handle errors seamlessly
medium.com
medium.com
. For example, a portion of config:
json
Copy
{ "id": "email", "label": "Email", "type": "email", 
  "validation": { "required": "Email is required", "pattern": "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$" }
}
might generate a Zod rule .min(1, "Email is required").email("Invalid email"). Custom business validations (beyond simple patterns) can be included via code references if necessary, but preferably we stick to declarative rules to avoid injecting code (see Security section on sanitization). The architecture thus preserves the strong form validation experience that Parker’s developers and users expect, while allowing these rules to be adjusted via config rather than code.
Multi-Step Forms and Conditional Logic (State Machines)
For progressive, multi-step booking flows with conditional branches, incorporate a state machine approach using XState (or a similar finite state machine library). A state machine can explicitly model each step (state) of the form wizard, and transitions based on events or conditions (guards). For example, a booking flow might have states: SelectFlight, PassengerInfo, Payment, Confirmation. Transitions like NEXT move forward, and conditions can skip or branch steps (e.g. if a user chooses a one-way trip, skip the return date step). XState allows defining such logic declaratively: e.g.,
ts
Copy
import { createMachine } from 'xstate';
const bookingMachine = createMachine({
  id: 'flightBooking',
  initial: 'selectFlight',
  context: { formData: {} },
  states: {
    selectFlight: {
      on: { NEXT: 'passengerInfo' }
    },
    passengerInfo: {
      on: { NEXT: [
        { target: 'payment', cond: 'hasValidPax' }
      ], PREV: 'selectFlight' }
    },
    payment: {
      on: { NEXT: 'confirmation', PREV: 'passengerInfo' }
    },
    confirmation: { type: 'final' }
  }
}, {
  guards: {
    hasValidPax: (ctx) => ctx.formData.adultCount > 0 // example guard
  }
});
This machine defines states and uses a guard (hasValidPax) to allow transitioning to payment only if passenger info is valid. In React, we can integrate XState with @xstate/react's useMachine hook to drive the UI. The current state determines which step component or which subset of fields to render. Using a statechart makes the flow structured and predictable, handling complex logic like skipping steps or looping back in a maintainable way
mayashavin.com
. Each state can also carry entry/exit actions, for example to trigger form validation or data saving when leaving a step, or to load dynamic options (like fetching updated prices at payment step). Notably, XState supports context data – we can store the form values in the state machine context or synchronize context with React Hook Form’s state. This ensures if a user navigates backward, their previous inputs persist. The machine can also handle global transitions like form submission success or failure, enabling a clean way to represent loading and error states (e.g. a state for submitting and then success or error). By modeling multi-step forms with a state machine, we prevent the “spaghetti” of manual step management. Instead of many boolean flags and if/else to manage step visibility, we have a single source of truth for form state. For example, Maya Shavin’s tutorial on XState wizards notes that as forms grow complex, state machines provide a scalable solution
mayashavin.com
mayashavin.com
. In that article, a sign-up form was refactored so that each step is a state and transitions are explicit events, making it easier to handle additional logic like async submissions or dynamic branches
mayashavin.com
mayashavin.com
. Adopting XState in Parker Flight’s multi-step booking will similarly make conditional paths (like showing different forms for round-trip vs one-way) easy to implement via state charts with guards. (For instance, a guard can check if tripType === 'roundtrip' to decide whether to include a “return date” step.) If XState’s bundle size (~>50KB) is a concern, consider lazy-loading the state machine logic only for the multi-step checkout flow. Alternatively, a simpler custom state management with React context or Zustand could be used, but would be harder to visualize and maintain for complex flows. Given the requirement for extensibility, XState’s visualizer and well-defined semantics are worth the bundle cost (which can be offset by code splitting so that casual search pages don’t load it).
UI Components with Tailwind and shadcn/ui
The form UI will leverage Tailwind CSS for utility-first styling and shadcn/ui (a library of Radix UI components pre-styled with Tailwind) for accessible form components. This means inputs, selects, checkboxes, etc., all come from a consistent design system and have built-in accessibility features. The shadcn/ui form primitives (like <Form>, <FormField>, <FormLabel>, <FormControl>, <FormMessage>) ensure that each field is wrapped with proper HTML structure, labels are associated with inputs, and error messages are linked and ARIA-announced. In other words, accessible markup and ARIA attributes are handled for us
ui.shadcn.com
, helping meet WCAG 2.1 AA. Using Tailwind utilities, the layout will be responsive (mobile-first). For instance, fields can be stacked on small screens and placed side-by-side on larger screens via Tailwind classes (the config might include layout hints like grouping certain fields). We should enforce consistent label placement and styling across forms (e.g. top-aligned labels for readability, as studies show they improve form completion speed
blog.boldtech.dev
blog.boldtech.dev
). The dynamic renderer will output the fields with the same structure as a static form, so we can easily apply Tailwind classes for spacing, grid layouts, etc., around the generated fields. Theming and variants: Tailwind makes it easy to update styles without affecting functionality, and because styles are in CSS, non-devs could even adjust basic styling via predefined utility classes in the config if we expose such options (for example, a field could have a class to hide it or change width). shadcn/ui’s components are unstyled by default except for essential styling, relying on our Tailwind design tokens – this keeps the bundle size small and avoids adding another heavy CSS framework. We will also ensure all interactive elements (inputs, buttons) are focusable and navigable by keyboard, with visible focus rings (Tailwind’s focus: classes help here). Error messages from validation will be rendered in <FormMessage> components which use role="alert" or similar for screen readers (shadcn’s implementation covers this). By building on these well-tested UI primitives, we reduce risk of accessibility bugs.
A/B Testing with Form Variants
To support A/B tests and gradual rollouts, the form architecture should allow multiple variants of a form configuration. There are a few strategies to enable this:
Variant IDs in Config: The config data model can include a notion of variants. For example, a form definition could have sub-objects for each variant (“Variant A” vs “Variant B”), or multiple form entries in the database distinguished by a version or variant field. Non-developers could create a new variant by duplicating a form config and tweaking it (e.g. different field order or wording).
Runtime Selection: The frontend can decide which variant to load based on an experiment assignment. For instance, Parker Flight might use a flag service or a percentage rollout. A simple approach is to have the backend (or Supabase function) randomly assign a user to variant A or B and return the corresponding config. Alternatively, the front-end could fetch both variants and choose one based on a hash of user ID or a query parameter.
Unified Rendering: The renderer can handle variant-specific fields by reading the chosen config. Because the form is built from config, switching to a different variant is just loading a different JSON. No code changes required – ideal for rapid A/B tests. For example, one variant could include an extra “Flexible Dates” toggle field, while another omits it; the dynamic renderer simply shows whatever is in the config for that variant.
To implement this cleanly, include a field in the config metadata like version: "A" or a separate table for form variants. During an A/B test, both variants are stored and a feature flag or user segmentation decides which ID to load. Supabase could even serve a view or RPC that selects the appropriate variant server-side. The key is that form variants are configurations, not code branches – meaning product can tweak or activate variants easily. This aligns with Retool’s philosophy of treating interfaces as data that can be swapped without redeploy. We also must ensure analytics hooks are in place: e.g., tag submissions by variant and track user drop-off per step to evaluate which config performs better. The architecture should log variant IDs with events (this can be done in the edge function when receiving the submission, or via front-end logging) to facilitate analysis of the A/B test outcomes.
Backend Architecture
Config Storage and Versioning (Supabase)
All form configurations and business rules will be stored centrally in Supabase (Postgres) for security and version control. We propose a schema roughly like:
forms table: fields: form_id (e.g. "flight_search"), active_version (FK to form_versions).
form_versions table: fields: id (PK), form_id (FK), version (int or semver), config_json (JSONB), created_at, created_by, is_active, etc.
Each time a form config is updated, a new row in form_versions is inserted (with an incremented version number or timestamp). The forms.active_version can point to the currently live config (allowing easy rollback by flipping this pointer). This provides a history of changes and easy reversion if a bad config is deployed. It also allows storing drafts (not marked active) for testing. Supabase’s row-level security can ensure that only authorized users (e.g. admins or CI service) can insert new versions (more on security below). The config JSONB can be validated against a JSON Schema or via application logic to ensure it meets the expected format. Storing config in Postgres JSONB means we can query it if needed (e.g. search across forms for a field), and it benefits from ACID transactions (so updating multiple tables for a version change is safe). Supabase also offers Branches and migrations, so config changes can be managed similarly to code if desired (for instance, treat certain config changes as data migrations in version control). However, since the goal is empowering non-devs, likely there will be an internal admin UI that writes to this table. For retrieval, the front-end or edge function can query Supabase to get the current config. This could be done via Supabase client in the front-end (if public read access is acceptable and safe) or via a Supabase Edge Function that returns the config (and could implement caching or access control logic). Given the config might include some business rules, a safer approach is to fetch it in the backend (Edge Function) and send to client – that way we can omit any truly sensitive parts (though ideally sensitive parts are encrypted or not sent to client at all). The query for config is simple (primary key lookup by form_id and active flag), so it’s very fast (especially if the JSON is moderate size). We can further optimize by caching the config in memory on the edge function side (e.g. keep a global variable or use Deno cache) to avoid hitting the DB on every request. Versioning also plays into A/B tests: the variant could be represented as separate versions or separate form_ids (e.g. flight_search_vA, flight_search_vB). Alternatively, have a single config JSON contain multiple variants under it. But isolating them as distinct versions may be cleaner for auditing. Finally, Supabase’s Realtime can be leveraged: if an admin updates a form config (inserting a new version and marking active), we can publish a notification so that running front-ends update. Supabase Realtime’s Postgres Changes feed allows clients to subscribe to table updates. We can subscribe to form_versions or a channel for a specific form_id. When a new active version is inserted, the front-end (if an admin interface or even the user app if we want instant updates) would get an event. The front-end could then refetch the config or use the event data (which includes the new JSON). This mechanism enables real-time form updates in a running app. For example, internal testers could see a form change live, or a hotfix to a form label could propagate without any reload. (In practice, for end-users, we might simply fetch fresh config on each page load and not maintain a continuous subscription, to save resources. Real-time is most useful in an admin preview context or if forms need to update while a user is on the page, which is rare.) To implement realtime safely, we must enable the table for replication in Supabase (via the Realtime settings) and ensure RLS policies allow the subscription. The Supabase docs note you can “listen to database changes in real-time from your application”. Using either the Broadcast feature or Postgres Changes feed, we’d ensure that only authorized clients (like admins, or the app itself) receive the events. In summary, the backend storage design treats form definitions as data with full version control, auditing, and real-time publication capabilities.
Dynamic Rules Engine for Form Logic
Some form behaviors and complex filtering logic will be driven by business rules that should be configurable as well. For instance, conditional field display (e.g. show field B only if A has value X), computed defaults (e.g. pre-select nearest airport based on user location), or validation that depends on multiple fields (e.g. prevent booking if return date is before departure). Additionally, the flight search filtering (handled by the existing FilterFactory.ts) might have rules for how form inputs map to search parameters (e.g. if “Non-stop only” checkbox is checked, add filter stops=0). We recommend using a lightweight rules engine or JSON-based expressions to encode these dynamic rules outside of hardcoded logic. This could be as simple as adding a conditional property in the config (as illustrated in FieldConfig above) to handle show/hide logic on the frontend. The form renderer can evaluate field.conditional: e.g., if field.conditional = {fieldId: 'tripType', equals: 'round-trip'}, then the renderer will only include that field if the tripType field’s value equals "round-trip". Such evaluation is trivial in front-end (just check form state), and can also be done in XState guards for multi-step routing. For more complex rules or backend-oriented business logic, consider using a JSON rules library. One example is json-rules-engine (a Node.js library) which allows defining rules in JSON and evaluating against a data object. According to a description, “json-rules-engine is a flexible, lightweight Node.js library that lets you define business rules in pure JSON.”
javascript.plainenglish.io
. We could define rules like “IF fareClass = ‘business’ AND userStatus = ‘gold’ THEN discount = 10%”. The rules engine can run in a Supabase Edge Function to compute outputs or validations. Another approach is JsonLogic (jsonlogic.com) which represents logical conditions as JSON (e.g. { "if": [ { "===": [ {"var":"tripType"}, "one-way" ] }, ... ] }). The advantage of JsonLogic is that it’s easily serializable and there are small JS evaluators for it. Because the rule is data, it can be built or changed dynamically
jsonlogic.com
, which fits our config-driven approach. In Parker Flight’s context, one set of rules might map form inputs to the filter pipeline. For example, the config could list filters like:
json
Copy
"rules": [
  { "if": [ {"var": "nonStop"}, true ], "then": {"filter": "maxStops", "value": 0} }
]
This rule means: if the nonStop field is true, then apply a filter setting maxStops = 0 in the search query. The edge function running the flight search can iterate through such rules and apply them using the existing FilterFactory (e.g. call FilterFactory.apply('maxStops',0) or similar). Essentially, the form submission handler becomes data-driven: it takes the form values and the config's rule list, and produces the appropriate filtered query or result. This decouples the UI from the logic of how a field affects the search. For dynamic calculations (like pricing rules or input derivations), we could allow small formula expressions in config (for example a rule engine could compute a field like “total passengers = adults + children”). These would be executed either on client or server depending on sensitivity. If on the client, we must sanitize thoroughly (no eval, only a safe expression evaluator). Inline expressions: A simpler alternative to a full rules engine for many cases is to support a limited set of expression syntax in the config, such as basic math or string interpolation. For example, a field default value could be "{{today() + 7d}}" to mean one week from today (with the form renderer interpreting that). This can be handled by a custom parser or lightweight library, ensuring no arbitrary code is run (only known functions). Security for rules is paramount: we will not execute raw JavaScript from the database. Instead, using structured JSON rules ensures that only the allowed operations can occur. The rules engine or evaluator should be whitelisted to certain functions (e.g. comparisons, arithmetic, but no access to global JS objects or DOM). On the backend, if we use a library like json-rules-engine, it can safely evaluate rules against a plain JSON object of form data. The rules themselves can be stored in the config JSON under a field or in a separate table if they are large or numerous. In summary, business logic is externalized into data-driven rules. This aligns with modern config-driven systems and ensures that even conditional form behaviors or filter mappings can be adjusted without code changes. We maintain system integrity by only allowing safe, predefined rule patterns to be configured. This rules subsystem would integrate with Parker Flight’s existing pipeline by producing inputs for it. For example, if FilterFactory expects certain parameters, our config can include a mapping (like a field’s id or name matches a filter function name, or an explicit map like "field":"maxStops", "param":"stops"). Then the submission handler does something like:
js
Copy
for (const field of formConfig.fields) {
  if (field.mapToFilter && formValues[field.id] != null) {
    filters[field.mapToFilter] = formValues[field.id];
  }
}
// then pass `filters` to FilterFactory
This approach reuses the robust existing logic (we’re not replacing how filtering works, just how inputs feed into it), ensuring the search results remain accurate.
Integration with FilterFactory and Pipeline
As mentioned, integrating with the existing filtering pipeline is achieved by mapping dynamic form inputs to the filter functions/parameters. The form config can carry this metadata. For instance, the config for a "Price Range" slider field might include "filterKey": "priceMinMax". The Edge Function (or client, depending on where filtering logic lives) will read form inputs and assemble a filter object or call FilterFactory methods accordingly. Because the form fields themselves are now dynamic, we can't rely on static code mapping each input. Instead, a generic mapping layer will interpret config:
Each field could have an attribute like filter: { type: 'number_range', param: 'price' } indicating this field contributes to price filter.
Or a simpler key approach: field id matches a known filter key in a dictionary.
The FilterFactory.ts might have methods or a config of its own. If it's something like an object with filter lambdas, we could do:
ts
Copy
import FilterFactory from './FilterFactory';
const filtersToApply = [];
formConfig.fields.forEach(field => {
  const val = formValues[field.id];
  if (val === undefined || val === "" || val === false) return; // skip unset fields
  if (field.filterKey) {
    filtersToApply.push( FilterFactory[field.filterKey](val) );
  }
});
const results = runSearchWithFilters(filtersToApply);
This pseudocode shows how minimal the code becomes: it doesn’t need to know about each field explicitly; it just uses the metadata from config to call the right filter. The actual FilterFactory code remains unchanged. Thus, as long as product team updates the config with correct filter mappings, the backend will automatically incorporate new filters. (We should validate config on save to ensure any filterKey references a real FilterFactory entry, to avoid runtime errors.) This design ensures backwards compatibility: initially, we populate the config with the same fields and filter mappings as the current hard-coded form. The search results should be identical. As new filters are introduced (say a new option to filter by aircraft type), we’d add it to FilterFactory (if needed) and simply add a field in config referencing it, no need to build UI by hand.
Real-Time Updates and Deployment
As noted earlier, Supabase Realtime can push config changes to the frontend. Additionally, we could utilize it for hot-reloading rules in the edge function. For instance, a Supabase Edge Function could cache the form config in a global, but subscribe to the Realtime channel for that config. If a new version is activated, the function invalidates its cache or fetches the new config. This ensures even long-running edge functions (if any) are aware of updates without redeployment. The overhead is low (a small websocket subscription) and ensures zero-downtime config deployments. However, care must be taken in a production environment: We don’t want partial updates (e.g., someone editing a config in progress to appear for end users). The versioning and activation flag help here – we only broadcast once a new config is fully saved and marked active. Also, frontend real-time update might not always be desirable for user experience (you wouldn’t want a user filling a form to have fields suddenly change). So in user-facing apps, you might use realtime only in admin mode or simply notify that “a new form version is available, please refresh”. In most cases, deploying form changes can be instantaneous by flipping the active version, but we can allow existing user sessions to continue with the old version if needed (e.g., if a user already loaded a form, that instance can continue to use the old config; the new config will apply on the next page load or search). In summary, the backend architecture treats form configs as first-class data with proper storage, version control, rule execution integration, and optional real-time distribution. This supports fast iteration (like how Retool or Stripe might manage their internal UIs) while ensuring the flight search pipeline continues to function with the new inputs.
Security & Performance
Sanitization and Injection Prevention
Allowing dynamic config and rules means we must guard against malicious or erroneous inputs in that config. Sanitize all inputs from the config before using them in the app:
No Raw HTML/Script: If the config includes any content that will be rendered (like field labels, help text), ensure it's inserted as plain text (React by default escapes content in JSX). Do not allow config to include HTML snippets that could lead to XSS. For example, if a field label is <img onerror=alert(1)>Name:</img>, the React app should treat it as a literal string (which React does, unless using dangerouslySetInnerHTML which we will avoid).
Validate Data Types: The config JSON should itself be validated (using Zod or JSON Schema) when saved. This prevents someone from inserting a value of wrong type that our code might not expect. For instance, if field.options is supposed to be an array of strings, we reject or sanitize anything else.
Rules Evaluation: For any rule or expression, use safe evaluators. Never use eval() on config-supplied strings. Instead, use libraries (json-rules-engine, JsonLogic, etc.) that are designed to evaluate expressions in a controlled manner. These libraries don’t execute arbitrary code; they only perform allowed operations (like comparisons, arithmetic).
SQL Injection: Since we may convert form inputs into query filters (SQL or API calls), we must parameterize any database queries. If Parker Flight’s filters hit a SQL database, use parameterized queries or ORMs to insert the values. The config itself should not directly contain any raw query snippets. If absolutely needed (e.g. a custom SQL for a filter), treat it carefully and allow only predefined, parameterized queries referenced by name.
Supabase Edge Function Safety: Edge Functions (likely running with Deno) should not execute untrusted code. Ensure that any dynamic logic on the backend is limited. For example, if you store a JavaScript snippet as a rule (not recommended), it could be dangerous. Better to stick to JSON logic which our code interprets. If a truly custom function is needed (say a complex calculation), implement it in the edge function code (TypeScript) behind a flag that can be toggled via config, rather than storing the code in the DB.
Overall, treat the config DB as part of the trusted system but review changes (through code review or admin approval) before promoting to production. We might implement an approval workflow for config changes if needed for extra safety. In terms of user input, the usual sanitization applies (the form fields themselves will be validated by Zod and any potentially harmful input from users (like script tags in a text field) can be either disallowed via validation or safely stored/escaped).
Access Control with RLS and Roles
Supabase allows fine-grained access control via Row Level Security (RLS). We will lock down the config tables so that:
Regular application users (using the public anon or authenticated role) have read-only access to the needed form configs (and possibly only to the active version). We can create a select policy: e.g. create policy "Allow read active form to anon" on form_versions for select using ( is_active ) to anon;. This would allow unauthenticated clients to read only active versions. Alternatively, we might decide not to expose direct DB read at all and only serve via a secured API.
Only privileged roles (e.g. an admin role or service key) can insert/update configs. For example, an internal admin interface could use the Supabase Service Key (which bypasses RLS) or we create an admin Postgres role. An RLS policy could say only a certain JWT claim (like role = 'admin') can insert or update in forms tables. Supabase maps every request to either anon or authenticated by default
supabase.com
, but we can add custom roles via JWT. We should ensure that the public API key (used by the front-end) is anon which has no write permission on these tables.
In practice, enabling RLS on the tables and writing explicit policies is critical because Supabase’s default behavior with the anon key (when RLS is off) would allow full CRUD. By turning on RLS (which is recommended for any exposed table
supabase.com
) and writing policies, we enforce the principle of least privilege. Example Policy:
sql
Copy
-- Allow only admin role to modify forms
create policy "Admin can modify forms" 
on form_versions for insert, update, delete 
to authenticated 
using ( auth.role() = 'service_role' or auth.jwt() ->> 'isAdmin' = 'true' );
This assumes we tag admin JWTs appropriately. Or simply, we don’t allow any direct modifications via client; instead, our admin dashboard backend uses the service key (which by design bypasses RLS but is never exposed to users). Also consider multi-tenancy: If Parker Flight had client-specific forms, RLS could segregate rows by tenant ID. But given it’s one product’s forms, probably not needed. Additionally, use Postgres row ownership if applicable. For instance, if we log created_by user ID on form_versions, we can ensure only that user or admins can edit their drafts. For production, likely only a small team has access anyway. In summary, Supabase RLS policies and JWT roles will ensure only authorized personnel can change configurations or sensitive rules, while end-users (or the app acting on their behalf) can only read what's necessary
supabase.com
. This prevents any potential abuse where someone could manipulate the forms by injecting a new config via the client.
Encryption of Sensitive Config Data (AWS KMS)
If certain configuration elements are highly sensitive (business secrets, pricing logic, partner contract rules, etc.), we should encrypt them at rest. Supabase does not have built-in KMS integration for arbitrary columns, but we can handle this at the application level using AWS KMS. For example, if the form rules contain a secret commission percentage or an API key for a third-party, instead of storing it in plaintext JSON, we store an encrypted blob. AWS KMS can manage the encryption keys securely. The workflow could be: an admin provides a secret value through a secure interface, the backend service calls AWS KMS to encrypt that value with a CMK (Customer Master Key) and stores the ciphertext in the config. At runtime, the Supabase Edge Function (which can have credentials to use KMS) will decrypt the value to use it. This way, even if the database is compromised or an unauthorized user reads the config, the sensitive parts are gibberish without KMS access. We can use the AWS KMS API or AWS Encryption SDK for this. Best practices include using a dedicated key for config data, enabling key rotation, and restricting KMS decrypt permissions to only the service role that runs the edge functions
docs.aws.amazon.com
. For instance, the Supabase Edge Functions (which run on Deno, possibly hosted on Supabase’s infra or vercel) could call AWS KMS via AWS SDK. If that’s not feasible due to environment, an alternative is to use libsodium (Supabase has an extension pgsodium for encryption) to encrypt data with a key stored in a secure Vault. AWS KMS Pros: We offload key management and have audit logs of key usage. If Parker Flight already uses AWS, this fits into their security model. As an example, a field in config might be:
json
Copy
{ "id": "specialFareCode", "type": "hidden", "encrypted": true, "value": "ENCRYPTED_CIPHERTEXT==", "description": "Encrypted fare discount formula" }
The front-end wouldn’t see or use this (maybe it’s only for backend logic). The edge function would decrypt it and apply it. We should also encrypt any PII or credentials that might be in config (though ideally credentials aren’t in the form config – they’d be in more secure storage). Additionally, leverage Supabase Secrets or environment variables for anything that shouldn’t even be in the DB. For example, if a rule says "call X API with key Y", better to store Y as a secret in the function environment and just reference it by name in the config. To summarize, encryption is an extra layer: We will encrypt sensitive business rules or config values using AWS KMS-managed keys, ensuring that even if config data is leaked, the secrets remain protected. Only authorized runtime with access to KMS can decrypt when needed, fulfilling compliance and security best practices.
Performance Optimization and Caching
Frontend Performance (Rendering < 100ms): The dynamic form should load and display very quickly. Strategies to achieve this:
Initial State Preload: The config JSON can be fetched ahead of time or embedded in the page for the initial load. For example, when the user navigates to the search page, the server could include the JSON in a <script type="application/json" id="formConfig"> tag, or the client could fetch it from Supabase with minimal overhead (Supabase is quite fast for such small queries, but an extra request can be avoided by bundling the config if it's not too large).
Memoization: The form renderer can memoize heavy computations (like building the Zod schema or the list of component elements) so that re-renders (when the user types) don’t recalc everything. However, RHF and uncontrolled inputs already minimize re-renders; each field is isolated. We just need to ensure building the form UI is efficient. Constructing ~20-50 React elements is trivial in 2025 JS engines, but if a form had hundreds of fields, we could implement virtualized rendering or split into sub-components per section so that not all mount at once.
Code Splitting: Load form-related code only when needed. For example, XState and multi-step components only load on the booking page. The search form (likely simpler) should be part of the main bundle but can be optimized (shadcn components are mostly small wrappers; RHF and Zod are already likely in use globally).
Bundle Size Control: By using our custom renderer and selective libraries, we stay within the <50KB budget. We avoid large form libraries; instead using RHF (~12KB) which is already in use, Zod (~25KB), and maybe XState (~40KB) lazy-loaded. Tailwind is CSS (no JS cost after build), and shadcn/ui components are mostly tree-shaken small pieces (Radix might add some KB, but manageable). If needed, we can prune unused Radix components from shadcn’s config to trim bundle. Also ensure not to import all icons or heavy libs unnecessarily.
UI Thread Efficiency: Keep DOM updates minimal. RHF’s uncontrolled inputs only update DOM on input and on error state changes. Using <FormField> from shadcn (which internally uses React context for registration) might add a small overhead, but still very fast. We can measure with React Profiler; it should easily be < 100ms for form with say 20 fields on a typical device. If we find any slowness (e.g., having a huge dropdown with thousands of options), we will implement optimizations like asynchronous loading of options or virtualization in selects.
API Performance (Edge Function < 2s): The end-to-end flight search or booking action triggered by the form submission should respond in under 2 seconds. The dynamic form architecture can aid performance in a few ways:
Efficient Filter Application: Using the mapping approach, we ensure only relevant filters are applied and we avoid any unnecessary processing. The Edge Function will get a structured filter input and directly call existing optimized search logic. No heavy transformation or conditional logic beyond what’s already needed.
Parallelism: If the search involves external API calls (e.g. calling multiple airline systems), the Edge Function can do those in parallel since it’s asynchronous. Ensure using Promise.all for any multi-fetch scenarios.
Caching Search Results: Although flight search results are highly dynamic, some caching can help, e.g., caching responses for identical queries for a short time (few minutes) to serve repeated searches (common routes might be searched often). A caching layer (like a Redis or even the Supabase Edge Function’s global cache or Vercel’s Edge cache if applicable) could store recent results keyed by query+date. This is outside the form system per se, but it's a backend perf consideration.
Content Delivery: Ensure responses (especially search results) use gzip/brotli compression (Supabase functions do this by default for JSON). 2s is the max; aim lower by optimizing queries, using database indexes for any direct DB queries (like if filtering flights in SQL, index on date, origin, destination, etc).
Supabase Edge Function cold starts: Keep an eye on cold start times; using Deno, cold start might be a couple hundred milliseconds. We might keep the function warm by periodic ping or using Supabase’s beta feature for persistent functions if available. Also, the dynamic form config retrieval in the function can be cached to avoid a DB query for each request (e.g., load config once and reuse, update on changes via realtime as discussed).
Profiling: Establish performance monitoring for the function (log execution time, maybe integrate with tracing). If the pipeline sometimes takes >2s (maybe in worst cases with many results), consider ways to trim (like limit results then paginate, or move heavy computations out of the request path).
Front-end Caching: We can cache form config on the client side as well. For example, store the fetched config in localStorage or IndexedDB with a version tag. On next visit, use it instantly and in background fetch to see if a new version is available. Because form configs might change relatively infrequently, this can reduce load time on repeat visits effectively to 0 for that part. The real-time mechanism or a version number from the server can inform the client when to invalidate the cache. CDN Edge Caching: If form config is considered public (no sensitive data), we could serve it via a CDN/edge cache. For instance, a route like /api/formConfig?form=flight_search could be cached for, say, 5 minutes at the CDN. But since we want rapid changes, perhaps short TTL or just rely on the small size and Supabase’s global network. Supabase itself doesn’t provide CDN caching for DB responses, but we could front it with Vercel or CloudFlare if needed. Accessibility & Mobile Performance: Ensuring accessibility can also aid performance (for example, proper semantics mean screen readers can parse more efficiently). Mobile-first design means we optimize for low-end device: the 100ms render should hold on a typical mid-range phone. Tailwind’s tiny CSS footprint and no jQuery etc. help keep it smooth. Use <input type="date"> and other native controls on mobile for better performance and UX (shadcn/ui wraps native where possible, e.g., selects might use a popover but that’s fine). Finally, continuously benchmark both frontend and backend:
Use Lighthouse or WebPageTest on the form page to ensure the additional script (for dynamic form logic) doesn’t regress LCP (Largest Contentful Paint) or TTI (Time to interactive).
Measure form render time by instrumentation (e.g., mark when config is fetched and when form is rendered).
Load test the edge function with typical traffic patterns to ensure <2s under load. If using Supabase’s serverless, watch out for rate limits or plan capacity, and use caching to mitigate.
By following these practices, we expect to meet or exceed the performance targets while retaining the flexibility of the solution.
Implementation Deliverables
Finally, to guide development, we outline key deliverables and how to implement them:
Code Examples and Components
1. Config Schema Definition – Define TypeScript types (and corresponding Zod schema) for the form configuration. This will be used both to validate incoming config changes and as documentation for what can be configured. For example:
ts
Copy
// config.schema.ts
import { z } from "zod";

const FieldTypeEnum = z.enum(["text","email","number","select","checkbox","date"]);
const FieldConfigSchema = z.object({
  id: z.string(),
  label: z.string(),
  type: FieldTypeEnum,
  required: z.boolean().optional(),
  options: z.array(z.string()).optional(),
  validation: z.object({
    minLength: z.number().optional(),
    maxLength: z.number().optional(),
    pattern: z.string().optional(),
    customError: z.string().optional()
  }).optional(),
  conditional: z.object({
    fieldId: z.string(),
    equals: z.any()
  }).optional(),
  filterKey: z.string().optional()
});
export const FormConfigSchema = z.object({
  formId: z.string(),
  title: z.string(),
  fields: z.array(FieldConfigSchema),
  // Could include rules, variant info, etc
  rules: z.array(z.any()).optional()  // if using JSONLogic, could refine this further
});
This schema (or a similar one) would be used when reading/writing configs to ensure they are well-formed. It also serves as a blueprint for building the form and the Zod validation for inputs. 2. Dynamic Form Renderer Component – Create a React component (e.g. <DynamicForm formId="flight_search" onSubmit={...} />) that:
Fetches the form config (maybe via a custom hook that uses Supabase).
Uses useForm from RHF with a resolver from the generated Zod schema (via a helper makeZodSchema(formConfig)).
Iterates over formConfig.fields and renders each field as shown in earlier examples, using shadcn’s <Form> and related components for structure.
Handles conditional field logic: possibly using RHF’s watch API to conditionally render fields. E.g., const watchTripType = watch("tripType"); then only render a return date field if watchTripType === "round-trip". Because the fields are in an array, we might filter them before rendering:
jsx
Copy
const visibleFields = formConfig.fields.filter(f => {
  if (!f.conditional) return true;
  const depVal = watch(f.conditional.fieldId);
  return depVal === f.conditional.equals;
});
Then map visibleFields to JSX. RHF’s watch will trigger re-render when the dependency field changes.
Binds form submission: uses handleSubmit to call the provided onSubmit or a default handler.
3. Supabase Rule Execution Example – Implement a Supabase Edge Function (in TypeScript, using the Deno environment) for flight search that uses the config:
ts
Copy
// pseudo-code in supabase/functions/flightSearch.ts
import { createClient } from '@supabase/supabase-client'; 
import { FilterFactory } from './FilterFactory';
import { FormConfigSchema } from './config.schema.ts';

const supabaseAdmin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

export async function handleFlightSearch(request) {
  const formData = await request.json();  // the submitted form values
  // Fetch the corresponding form config (could also be cached)
  const { data, error } = await supabaseAdmin.from('form_versions')
    .select('config_json').eq('form_id', 'flight_search').eq('is_active', true).single();
  if (error) { return new Response("Config fetch error", { status: 500 }); }
  const formConfig = data.config_json;
  // Validate formData against Zod schema to be safe
  const parseResult = FormConfigSchema.pick({ fields: true }).safeParse(formData);
  if (!parseResult.success) {
    return new Response(JSON.stringify({ errors: parseResult.error.flatten() }), { status: 400 });
  }
  // Build filters
  const filters = {};
  for (const field of formConfig.fields) {
    const val = formData[field.id];
    if (field.filterKey && val !== undefined && val !== null && val !== "") {
      filters[field.filterKey] = val;
    }
  }
  // Apply filters using existing pipeline
  let results = await FilterFactory.applyFilters(filters);
  // (FilterFactory.applyFilters is assumed to return flight search results, possibly querying a DB or API)
  
  return new Response(JSON.stringify({ results }), { status: 200 });
}
This example shows retrieving the config and using it to map form data to filter parameters. In a real implementation, you would integrate with the actual FilterFactory logic. If the pipeline expects a different format (e.g. a class with chainable filter methods), adapt accordingly (maybe call FilterFactory.withMaxStops(val) for a filterKey "maxStops" etc., in a dynamic way using e.g. FilterFactory[field.filterFn](val) if FilterFactory exports functions). If using a rule engine for more complex logic, you would integrate it here. For instance, using jsonLogic.apply(rules, formData) if rules are part of config. Or if some rules are meant to run on the client (like show/hide), those can be omitted here; only include rules that affect backend processing (like altering query parameters or computing derived values). 4. XState Multi-step Flow Integration – Provide an example of using XState in the front-end for a form wizard:
Define a machine (as earlier code snippet showed) in a separate file, possibly even generated from config if the steps and transitions are configurable. (We could conceive a config format for steps and next logic, but that might be overkill; often the flow is relatively fixed per form.)
Use useMachine(bookingMachine) in a component that wraps multiple <DynamicForm> or step components.
For instance, have <FlightBookingWizard> component which holds the machine, and inside it conditionally renders <DynamicForm> for each step's fields, or even better, reuses one DynamicForm but with fields filtered to those belonging to the current step.
XState context can hold the cumulative form data across steps. On each step submission, merge into context and fire send('NEXT') to advance.
Code example:
jsx
Copy
const [state, send] = useMachine(bookingMachine);
const currentStep = state.value; // e.g. 'selectFlight' | 'passengerInfo' | ...
const stepConfig = formConfig.fields.filter(f => f.step === currentStep);

return (
  <Form onSubmit={handleStepSubmit}>
    {stepConfig.map(renderField)}
    <button type="button" onClick={() => send('PREV')} disabled={state.matches('selectFlight')}>Back</button>
    <button type="submit">{ state.matches('payment') ? 'Pay & Finish' : 'Next' }</button>
  </Form>
);
// handleStepSubmit will validate current step, update context (send update event with partial data), then send('NEXT') if all good.
The XState machine would be configured with proper transitions; a guard could prevent NEXT if validation fails, but since RHF+Zod handle validation before calling handleStepSubmit, we only call send('NEXT') when data is valid.
Provide a code snippet for machine guard:
ts
Copy
// In XState machine options:
guards: {
  isRoundTrip: (ctx) => ctx.formData.tripType === 'round-trip'
}
// Then transition:
selectFlight: { on: { NEXT: 'passengerInfo' } },
passengerInfo: { 
  on: { 
    NEXT: [
      { target: 'returnFlight', cond: 'isRoundTrip' },
      { target: 'payment' } 
    ] 
  } 
},
This ensures the returnFlight step is only entered if the user selected round-trip. This logic is entirely configuration-driven if tripType is a field in the form config and we define the guard accordingly. We could even generate such guards from config if we annotate a step with "show if field X equals Y". But at some point, it might be simpler to encode directly in machine code. The architecture can accommodate either.
5. Migration Strategy Plan – We will implement the new system alongside the existing one, migrating incrementally:
Side-by-side Launch: Initially, we can wrap existing forms in a feature flag. For example, have a prop or environment variable USE_DYNAMIC_FORM – if true, render <DynamicForm formId="flight_search">, if false, render the legacy form component. This allows testing the dynamic form in production (or staging) with real traffic by toggling the flag, or doing an A/B test where some percentage sees the new form. Because the form functionality should be identical, we measure that conversion or errors are on par with the old form.
Gradual Rollout: Start with one form (perhaps the search form, as it’s simpler than multi-step booking). Ensure it covers all existing features (e.g., date pickers, passenger count selectors, etc. – some custom UI elements might need to be implemented in the config system, or we temporarily allow a “custom component hook” for something truly bespoke). Once the search form is stable with config-driven approach, move to the booking flow.
Parallel Data Submission: During testing, we could even submit via both pipelines (e.g., when user submits on dynamic form, also submit via old endpoint in the background and compare results) to validate that the new path yields the same outcome. This might be useful for search results comparison, to ensure the mapping of filters is correct.
Backwards Compatibility: Keep the old code path available until we’re confident. If any critical issue arises with the dynamic form, the flag can revert to the static form instantly (fallback plan).
Developer Adoption: Train the dev team and product team on how to create and edit configs. Perhaps start by letting developers themselves encode a few forms as config (ensuring the format covers all needs), then involve product managers in tweaking text or adding a field via config in a lower environment to get them comfortable.
Tooling: Provide a simple admin UI for editing form configs (this could be as simple as a JSON editor with validation, or a form builder interface if time permits). Using something like the Supabase Studio or even Retool itself could be a quick way for internal users to edit config rows in a safer manner than directly in a SQL prompt.
Phased Deprecation: As each form is migrated to config-driven, remove or comment out the old form code and associated logic (to avoid confusion and double-maintenance). Keep it in source control history but not active. Monitor user feedback and metrics closely after each migration.
Edge Cases: Identify any features that are hard to configure (for example, maybe a very custom widget or third-party integration in a form). Plan how to handle those – either extend the config format or temporarily keep a bit of custom code. Over time, aim to eliminate all hard-coded forms.
The end goal is that all user-facing forms (search, booking, account, etc.) are served from config. The migration will be successful when adding a new field or changing a validation no longer requires a developer commit/deploy, but simply a config change by a product team member.
MVP Definition
To deliver value early, define a Minimum Viable Product for this system:
Scope of MVP: Implement the dynamic form system for one crucial form (e.g., the flight search form). This form is usually simpler (origin, destination, dates, passengers, etc.) and a good proving ground. MVP would include the front-end dynamic rendering of this form, reading from config, with Zod validation and integration to the search function.
Core Features:
A working config fetch (maybe hardcode a sample JSON or fetch from a dev Supabase table).
Dynamic form renderer that supports a subset of field types (text, select, checkbox, date).
Basic validation rules (required, maybe pattern).
Submission that hits either a stub or actual search logic, confirming the values are received.
Ensure performance is acceptable with this one form.
Non-dev Editing: For MVP, it could be acceptable that a developer loads the config JSON into the DB. Non-dev UI for editing can come slightly later, unless using a quick solution like providing access through Supabase UI. The key is demonstrating that a config change (even if done in the DB console) updates the form without code changes.
Exclusions: Multi-step flow and realtime updates could be beyond MVP if not strictly needed for first deliverable. If the search form is single-step, we might push multi-step (booking) to next phase. A/B testing infrastructure might also be later (though simply being able to swap configs could be shown).
Security in MVP: Ensure at least basic RLS so we’re not exposing write access. KMS encryption can likely be deferred unless the search form has something sensitive (which it probably doesn’t; it’s mostly fields like location and date).
Success Criteria for MVP: Product managers can request a form change (e.g. “make return date optional” or “add a cabin class dropdown”) and the team can implement it by updating config and reloading, rather than coding a new component. Measure how quickly a change can be propagated (e.g. <1 hour including testing, rather than a full deploy cycle).
Having the MVP in production (perhaps hidden or at low traffic) will allow iterative hardening. Then we expand to multi-step booking: that will introduce the XState integration, more complex validations (e.g. passport info formats), and perhaps encryption (if storing any payment rule, though likely payment will still use Stripe or external means).
Success Metrics
We will define clear metrics to evaluate the success of the new form architecture, focusing on developer efficiency, user experience, and system performance:
Developer Velocity: Track the time/effort for form changes before vs after. For instance, adding a new filter option in the search form used to require writing React code + tests (maybe 1-2 days of work and a deployment). In the new system, it might take 1 hour of config editing and QA. Our goal is to reduce form iteration time by at least 50-70%. We can measure “config deployments” frequency – expecting it to increase because it’s easier/safer to do (which is good, meaning product can refine forms more often).
Deployment Frequency: Count how many production deployments are tied to form changes. This should drop significantly. Ideally, after full adoption, 0 front-end deployments are needed solely for copy/layout changes in forms; and only rare backend deployments if a totally new kind of rule or filter logic is needed.
User Experience: We monitor form conversion rates (e.g. how many users successfully complete the booking flow). The new architecture should not negatively impact conversion – in fact, with easier A/B testing and tweaks, it should improve over time. We will measure drop-off at each step of the funnel, and expect either neutral or positive changes. Also measure form load time on client (target <100ms render after initial load) – using performance marks or Real User Monitoring to verify this threshold is met on various devices.
Accessibility Compliance: Perform accessibility audits (using tools like axe-core or Lighthouse accessibility tests) on the forms. Metrics here include 0 critical accessibility violations. Because we use semantic components, we expect to maintain WCAG 2.1 AA compliance, ensuring things like proper label associations and keyboard navigation are all functional. We can have QA do screen reader tests and ensure the experience didn’t regress from the static form.
Performance Metrics:
Frontend: Time to render the form UI (perhaps measured from the moment the config is available to the moment inputs are interactive). Aim for under 100ms on average devices. Also measure the bundle size impact – we set a budget of +<50KB gzipped JS. We will track bundle size in CI; success is staying within budget.
Backend: Flight search API response time. We will use monitoring (like logging execution time or using an APM) to ensure the /search and /booking endpoints stay under 2 seconds 95th percentile. If the average is currently, say, 1.5s, we ensure it remains around that or better. We’ll also watch memory/CPU on the edge function – the dynamic config lookup should be negligible, but we ensure it doesn’t cause any timeouts or resource spikes.
Additionally, if using caching, measure cache hit rates for form config or repeated queries to ensure efficiency.
System Reliability: Monitor error rates. A mis-configured form could cause errors (like missing expected field, etc.). We will implement logging that validates the config each time it’s loaded and perhaps catches any inconsistency (e.g., if a field says filterKey:X but FilterFactory has no X – log a warning). We aim for no increase in error rates after rollout. Success here is also having the ability to rollback quickly (via config versioning) if something goes wrong – measure rollback time (target a few minutes to identify and flip a version, vs hours to revert a code deployment previously).
Non-functional improvements: A metric could be stakeholder satisfaction – e.g., product team feedback that they can now adjust forms without waiting for a deployment. This is qualitative but important: essentially the architecture is successful if it empowers those teams and reduces the back-and-forth with engineering for simple form changes.
By continuously tracking these metrics, Parker Flight can ensure the new architecture is delivering on its promise: development speed-up, A/B agility, and high-performing, user-friendly forms. We will iterate based on these metrics – for example, if any performance target is not met, we’ll profile and optimize that area (perhaps caching more aggressively or simplifying the config).
In conclusion, this configuration-driven form architecture provides Parker Flight with a secure, fast, and extensible solution. It draws inspiration from industry leaders by treating UI as data: much like Retool, it enables real-time UI updates from config changes
reddit.com
; akin to Stripe’s internal tools, it emphasizes reliability and fine-grained control; and following the Google Flights ethos, it aims for snappy performance and rich interactivity in the flight booking domain. By carefully addressing frontend rendering, backend logic, security, and performance, the proposed design will allow Parker Flight’s team to iterate rapidly on form UX (testing new ideas via variants) without sacrificing the robustness of the user experience or the safety of the system. The end result is a win-win: developers spend less time on form minutiae and more on core product features, and users benefit from more up-to-date, well-tuned forms that maintain the high standards of accessibility and speed expected of a modern travel application. Sources:
Nagendra Mirajkar, "Crafting Dynamic Forms in React with a JSON Schema", Medium, 2023 – on benefits of JSON-schema-driven forms
medium.com
.
Sushil Kundu, "Building Dynamic Forms with React Hook Form and React", Medium, 2023 – notes on using JSON schema + RHF for flexible forms
medium.com
medium.com
medium.com
.
Reddit discussion, "JSON Schema-Driven Dynamic Form Builder for React.js" (r/reactjs) – highlights real-time form updates and validation integration via schema
reddit.com
reddit.com
.
Maya Shavin, "Managing Multi-Step Forms ... with XState", 2025 – advocates using XState for structured multi-step form logic
mayashavin.com
mayashavin.com
.
The Widlarz Group, "Multistep form handling ... with State Machines" – explains how UI can be rendered based on finite state machine states
thewidlarzgroup.com
.
Supabase Docs – Subscribing to Database Changes: outlines how to listen to Postgres changes in real-time.
Supabase Docs – Row Level Security: describes roles (anon, authenticated) for use in access policies
supabase.com
.
AWS Prescriptive Guidance – notes on using AWS KMS for encrypting sensitive data (database encryption, keys management)
docs.aws.amazon.com
.
shadcn/ui Docs – React Hook Form guide: emphasizes accessible, well-structured forms and integration with Zod and Radix components
ui.shadcn.com
ui.shadcn.com
.
Sophie Becker, "9 great ways to improve your forms in Retool", BoldTech, 2021 – UX tips for form design (e.g. label alignment) relevant to maintaining usability in the new system
blog.boldtech.dev
blog.boldtech.dev
.
Nected.ai blog, "Rule the Development Realm With JSON Rules Engine", 2023 – on benefits of JSON-based rule engines for dynamic business logic
javascript.plainenglish.io
.