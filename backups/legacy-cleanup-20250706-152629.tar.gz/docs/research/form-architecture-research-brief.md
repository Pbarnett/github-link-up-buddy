# Form Architecture Research Brief: Dynamic Flight Search Configuration

## Problem Statement

We need to architect a flexible form system for a flight search application that supports two main use cases:
1. **Autobooking Form** - Creates persistent flight monitoring rules
2. **Current Search Form** - Performs immediate live flight searches

### Core Challenge
Currently, making changes to form fields, filters, UX/UI, or business logic requires code changes across multiple files. We need a system where we can:
- Add/remove filters from either form without code changes
- Change field UX/UI presentation (layout, validation, input types)
- Create progressive forms (multi-step workflows)
- Maintain business logic separation from UI concerns

### Specific Pain Points

1. **Filter Management**: Core business rule: "we only search for round trip flights" is hard-coded throughout the system
2. **Field Coupling**: Form fields are tightly coupled to validation, business logic, and API mapping
3. **UX Inflexibility**: Converting single-page forms to progressive multi-step requires extensive refactoring
4. **Business Logic Duplication**: Same filtering logic exists in multiple places (forms, backend, API layers)

## Current Architecture Context

### Technology Stack
- **Frontend**: React, TypeScript, React Hook Form, Zod validation
- **Backend**: Supabase Edge Functions, PostgreSQL
- **APIs**: Amadeus (search), Duffel (booking)
- **State Management**: React Query, Zustand

### Current Form Structure

**Autobooking Form** (`CampaignForm.tsx`):
```
- Campaign Details (name, destination, dates)
- Trip Preferences (duration, cabin class, direct flights)
- Budget & Auto-booking (max price)
```

**Search Form** (`TripRequestForm.tsx`):
```
- Enhanced Destination Section
- Departure Airports Section  
- Date Picker Section
- Travelers & Cabin Section
- Budget Section
- Collapsible Filters Section
- Auto-booking Section (conditional)
```

### Current Business Rules (Hard-coded)
1. **Round-trip only**: Always searches round-trip flights
2. **Nonstop required**: All flights must be direct
3. **Carry-on included**: All prices include carry-on baggage
4. **Auto-booking validation**: Requires max price + payment method when enabled

### Current Filtering System
Located in `src/lib/filtering/` with:
- `FilterFactory.ts` - Central filter configuration
- `FilterPipeline.ts` - Execution engine
- Individual filters: `BudgetFilter`, `RoundTripFilter`, `NonstopFilter`, etc.

## Research Objectives

### Primary Question
**What is the best architectural pattern for creating a flexible, configuration-driven form system that separates business logic from UI concerns while supporting progressive form workflows?**

### Secondary Questions

1. **Configuration Storage**: Should form configurations be stored in database, files, or hybrid approach?

2. **Business Rule Engine**: How to implement dynamic business rules that can be toggled without code deployment?

3. **Progressive Forms**: Best patterns for converting single-page forms to multi-step workflows without breaking existing functionality?

4. **Validation Architecture**: How to maintain type safety with dynamic form configurations?

5. **UI Component Strategy**: Should we use a headless form library, custom component system, or existing solutions?

6. **Performance**: How to ensure dynamic forms don't impact runtime performance for flight search (time-critical application)?

## Research Areas to Investigate

### 1. Form Architecture Patterns
- **Configuration-driven forms** (JSON/YAML configs)
- **Headless form libraries** (React Hook Form, Formik, Final Form)
- **Schema-based forms** (JSON Schema, Yup, Zod)
- **Code generation approaches** (form builders that generate code)
- **Micro-frontend patterns** for form sections

### 2. Business Rule Engines
- **Rule engines** (json-rules-engine, nools, DMN implementations)
- **Policy engines** (Open Policy Agent, Cedar)
- **Configuration management** (feature flags, A/B testing platforms)
- **Domain-specific languages** for business rules

### 3. Progressive Form Patterns
- **State machines** (XState, Stately)
- **Multi-step form libraries** 
- **Wizard patterns** with conditional branching
- **Save/resume capabilities** for complex forms

### 4. Enterprise Form Solutions
- Study how these companies handle complex form requirements:
- **Stripe Dashboard** (payment configuration forms)
- **Salesforce** (custom object forms)
- **Monday.com** (dynamic board configurations)
- **Airtable** (base and field configuration)
- **Retool/Bubble** (visual form builders)

### 5. Travel Industry Specific
- **Expedia/Booking.com** search forms
- **Google Flights** filter architecture
- **Kayak** form progression
- How travel sites handle complex search criteria

## Success Criteria for Proposed Solution

### Must Have
1. **Zero Code Deployment** for filter add/remove
2. **Type Safety** maintained with TypeScript
3. **Performance** no degradation in search response times
4. **Backward Compatibility** existing forms continue working during migration
5. **Progressive Enhancement** can convert single-page to multi-step without breaking changes

### Should Have
1. **A/B Testing** support for different form configurations
2. **Analytics Integration** for form performance tracking
3. **Version Control** for form configurations
4. **Preview Mode** to test configurations before deployment
5. **Rollback Capability** for problematic configurations

### Could Have
1. **Visual Form Builder** for non-technical users
2. **AI-assisted** form optimization
3. **Multi-tenant** support for different form configurations per user segment
4. **Internationalization** support for different markets

## Constraints and Requirements

### Technical Constraints
- Must work with existing React Hook Form + Zod setup
- Cannot break existing API contracts
- Must maintain current performance characteristics
- Should leverage existing filtering system in `src/lib/filtering/`

### Business Constraints
- Flight search is time-critical (users expect <2 second responses)
- Forms must maintain high conversion rates
- Auto-booking reliability is critical (handles real money)
- Must support rapid iteration for A/B testing

### User Experience Requirements
- Forms must remain intuitive and fast
- Progressive forms should feel natural, not forced
- Mobile-first design must be maintained
- Accessibility (WCAG 2.1 AA) compliance required

## Example Scenarios to Address

### Scenario 1: Remove Nonstop Filter
**Current**: Requires code changes in 5+ files
**Desired**: Change configuration flag, redeploy only config

### Scenario 2: Add "Preferred Airlines" Filter
**Current**: Create new component, update validation, modify API, update business logic
**Desired**: Add to configuration, business logic automatically applies

### Scenario 3: Convert Search Form to 3-Step Progressive
**Current**: Major refactoring of component structure
**Desired**: Update form configuration to define steps

### Scenario 4: A/B Testing Form Layouts
**Current**: Feature flags in multiple components
**Desired**: Different form configurations based on user segment

## Deliverables Expected

1. **Architectural Recommendation** with specific technology choices
2. **Implementation Roadmap** with migration strategy
3. **Code Examples** showing key patterns
4. **Performance Analysis** of recommended approach
5. **Risk Assessment** and mitigation strategies
6. **Comparison Matrix** of evaluated approaches

## Additional Context

### Current Codebase Structure
```
src/
├── components/
│   ├── autobooking/CampaignForm.tsx
│   ├── trip/TripRequestForm.tsx
│   └── trip/sections/               # Form sections
├── lib/
│   ├── filtering/                   # Business logic filters
│   └── repositories/               # Data layer
├── types/form.ts                    # Form type definitions
└── hooks/                          # Form-related hooks
```

### Key Files to Consider
- `src/components/trip/TripRequestForm.tsx` - Main search form (634 lines)
- `src/components/autobooking/CampaignForm.tsx` - Autobooking form (272 lines)
- `src/lib/filtering/FilterFactory.ts` - Central filter configuration
- `src/types/form.ts` - Form type definitions and Zod schemas
- `docs/forms/form_architecture.md` - Current architecture documentation

### APIs and Integration Points
- **Amadeus API**: Real-time flight search
- **Duffel API**: Flight booking
- **Stripe API**: Payment processing
- **Supabase**: Database and edge functions

## Current Implementation Examples

### Current Form Field Definition (React Hook Form + Zod)
```typescript
// From src/types/form.ts
export const tripFormSchema = z.object({
  earliestDeparture: z.date({
    required_error: "Earliest departure date is required",
  }).refine((date) => date > new Date(), {
    message: "Earliest departure date must be in the future",
  }),
  latestDeparture: z.date({
    required_error: "Latest departure date is required",
  }),
  min_duration: z.coerce.number().int().min(1).max(30),
  max_duration: z.coerce.number().int().min(1).max(30),
  max_price: z.coerce.number().min(100).max(10000),
  nyc_airports: z.array(z.string()).optional(),
  other_departure_airport: z.string().optional(),
  destination_airport: z.string().optional(),
  destination_other: z.string().optional(),
  nonstop_required: z.boolean().default(true),
  baggage_included_required: z.boolean().default(false),
  auto_book_enabled: z.boolean().default(false).optional(),
  preferred_payment_method_id: z.string().optional().nullable(),
}).refine((data) => data.latestDeparture > data.earliestDeparture, {
  message: "Latest departure date must be after earliest departure date",
  path: ["latestDeparture"],
}).refine((data) => {
  // Auto-booking validation: require max_price and payment method
  if (data.auto_book_enabled) {
    return data.max_price && data.preferred_payment_method_id;
  }
  return true;
}, {
  message: "Maximum price and payment method are required for auto-booking",
  path: ["preferred_payment_method_id"],
});

export type FormValues = z.infer<typeof tripFormSchema>;
```

### Current Form Component Structure
```typescript
// Simplified version of TripRequestForm.tsx
const TripRequestForm = ({ tripRequestId, mode = 'manual' }) => {
  const [currentStep, setCurrentStep] = useState<1 | 2>(1);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(tripFormSchema),
    defaultValues: {
      min_duration: 3,
      max_duration: 7,
      max_price: 1000,
      nyc_airports: [],
      nonstop_required: true,
      auto_book_enabled: mode === 'auto',
    },
  });

  return (
    <FormProvider {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)}>
        {/* Step 1: Trip Basics */}
        {(mode === 'manual' || currentStep === 1) && (
          <>
            <EnhancedDestinationSection control={form.control} />
            <DepartureAirportsSection control={form.control} />
            <ImprovedDatePickerSection control={form.control} />
          </>
        )}
        
        {/* Step 2: Price & Payment (auto mode only) */}
        {mode === 'auto' && currentStep === 2 && (
          <>
            <EnhancedBudgetSection control={form.control} />
            <AutoBookingSection control={form.control} mode={mode} />
          </>
        )}
        
        {/* Manual mode: All sections visible */}
        {mode === 'manual' && (
          <>
            <TravelersAndCabinSection control={form.control} />
            <EnhancedBudgetSection control={form.control} />
            <CollapsibleFiltersSection control={form.control} />
          </>
        )}
      </form>
    </FormProvider>
  );
};
```

### Current Form Section Example
```typescript
// From EnhancedBudgetSection.tsx
const EnhancedBudgetSection = ({ control }: { control: Control<any> }) => {
  return (
    <FormField
      control={control}
      name="max_price"
      render={({ field }) => (
        <FormItem>
          <FormLabel>Top price you'll pay</FormLabel>
          <FormControl>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
              <Input
                type="number"
                min="100"
                max="10000"
                step="1"
                placeholder="1000"
                className="pl-6"
                {...field}
              />
            </div>
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};
```

### Current Business Logic Filter Example
```typescript
// From src/lib/filtering/FilterFactory.ts
export class FilterFactory {
  static createStandardPipeline(): FilterPipeline {
    const pipeline = new DefaultFilterPipeline(config, logger);
    
    // Add filters in priority order
    pipeline.addFilter(new RoundTripFilter());        // Priority 5
    pipeline.addFilter(new BudgetFilter());           // Priority 10
    pipeline.addFilter(new CarryOnFilter());          // Priority 12
    pipeline.addFilter(new NonstopFilter());          // Priority 15
    pipeline.addFilter(new AirlineFilter());          // Priority 20
    
    return pipeline;
  }
  
  static createFilterContext(searchParams: {
    budget?: number;
    currency?: string;
    nonstopRequired?: boolean;
    // ... other params
  }): FilterContext {
    return {
      budget: searchParams.budget || 0,
      currency: searchParams.currency || 'USD',
      nonstop: searchParams.nonstopRequired ?? false,
      // ... other context
    };
  }
}
```

### Current Data Flow
```typescript
// Form submission flow
const onSubmit = async (data: FormValues) => {
  // 1. Transform form data
  const transformedData = transformFormData(data);
  
  // 2. Create trip request
  const tripRequest = await createTripRequest(transformedData);
  
  // 3. Trigger flight search with business rules
  await invokeFlightSearch({
    tripRequestId: tripRequest.id,
    relaxedCriteria: false
  });
  
  // 4. Navigate to results
  navigate(`/trip/offers?id=${tripRequest.id}&mode=${mode}`);
};

// Transform function maps UI fields to API format
const transformFormData = (data: FormValues): ExtendedTripFormValues => {
  const departureAirports: string[] = [];
  if (data.nyc_airports?.length > 0) {
    departureAirports.push(...data.nyc_airports);
  }
  if (data.other_departure_airport) {
    departureAirports.push(data.other_departure_airport);
  }
  
  return {
    earliestDeparture: data.earliestDeparture,
    latestDeparture: data.latestDeparture,
    departure_airports: departureAirports,
    destination_airport: data.destination_airport || data.destination_other,
    budget: data.max_price,
    nonstop_required: data.nonstop_required,
    auto_book_enabled: data.auto_book_enabled,
    max_price: data.auto_book_enabled ? data.max_price : null,
  };
};
```

## Current Pain Points with Code Examples

### Pain Point 1: Hard-coded Business Rules
```typescript
// This logic is duplicated across multiple files:

// In TripRequestForm.tsx
defaultValues: {
  nonstop_required: true, // Hard-coded business rule
}

// In FilterTogglesSection.tsx
<div>Nonstop flights only</div>
<div>All flights shown are direct with no stops.</div>

// In FilterFactory.ts
pipeline.addFilter(new RoundTripFilter()); // Always round-trip
pipeline.addFilter(new NonstopFilter());   // Always nonstop

// In backend edge function
const isRoundTrip = !!tripRequest.return_date; // Always true in our app
```

### Pain Point 2: Tightly Coupled Form Sections
```typescript
// Each section is a separate component with its own logic:
const TripRequestForm = () => {
  return (
    <>
      <EnhancedDestinationSection control={form.control} />
      <DepartureAirportsSection control={form.control} />
      <ImprovedDatePickerSection control={form.control} />
      <TravelersAndCabinSection control={form.control} />
      <EnhancedBudgetSection control={form.control} />
      {/* Adding new section requires code changes */}
    </>
  );
};

// To make progressive, we need conditional rendering:
{mode === 'auto' && currentStep === 1 && (
  <EnhancedDestinationSection control={form.control} />
)}
{mode === 'auto' && currentStep === 2 && (
  <EnhancedBudgetSection control={form.control} />
)}
```

### Pain Point 3: Validation Coupling
```typescript
// Validation rules are mixed with field definitions:
const tripFormSchema = z.object({
  max_price: z.coerce.number().min(100).max(10000), // UI validation
}).refine((data) => {
  // Business logic validation mixed in
  if (data.auto_book_enabled) {
    return data.max_price && data.preferred_payment_method_id;
  }
  return true;
}, {
  message: "Maximum price and payment method are required for auto-booking",
});
```

## Database Schema Context

### Trip Requests Table
```sql
CREATE TABLE trip_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id),
  destination_airport TEXT,
  destination_location_code TEXT NOT NULL,
  departure_airports TEXT[] NOT NULL DEFAULT '{}',
  earliest_departure TIMESTAMPTZ NOT NULL,
  latest_departure TIMESTAMPTZ NOT NULL,
  min_duration INTEGER NOT NULL DEFAULT 3,
  max_duration INTEGER NOT NULL DEFAULT 7,
  budget NUMERIC NOT NULL,
  max_price NUMERIC, -- For auto-booking
  nonstop_required BOOLEAN NOT NULL DEFAULT true,
  baggage_included_required BOOLEAN NOT NULL DEFAULT false,
  auto_book_enabled BOOLEAN NOT NULL DEFAULT false,
  preferred_payment_method_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

### Flight Offers Table
```sql
CREATE TABLE flight_offers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_request_id UUID NOT NULL REFERENCES trip_requests(id),
  airline TEXT NOT NULL,
  price NUMERIC NOT NULL,
  departure_date DATE NOT NULL,
  return_date DATE NOT NULL,
  duration TEXT NOT NULL,
  stops INTEGER NOT NULL DEFAULT 0,
  baggage_included BOOLEAN NOT NULL DEFAULT false,
  booking_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

## Performance Requirements Context

### Current Performance Metrics
- Form render time: <100ms
- Form validation: <50ms
- API submission: <500ms
- Flight search initiation: <200ms
- Total form-to-results: <2 seconds

### Critical User Flows
1. **Quick Search**: User fills basic fields, clicks search (80% of usage)
2. **Auto-booking Setup**: User configures monitoring rules (15% of usage)
3. **Progressive Setup**: User guided through complex configuration (5% of usage)

### Load Patterns
- Peak: 1000 concurrent form submissions
- Average: 100 concurrent users
- Form abandonment rate: <15% (current)
- Mobile usage: 60% of traffic

## Additional Technical Context

### Current Component Dependencies
```typescript
// Key dependencies that new architecture must work with:
{
  "react": "^18.2.0",
  "react-hook-form": "^7.45.0",
  "@hookform/resolvers": "^3.1.0",
  "zod": "^3.21.4",
  "@tanstack/react-query": "^4.29.0",
  "zustand": "^4.3.8",
  "@supabase/supabase-js": "^2.26.0",
  "tailwindcss": "^3.3.0"
}
```

### Current Field Type Patterns
```typescript
// Different input types currently used:
- Text inputs: destination_other, other_departure_airport
- Number inputs: min_duration, max_duration, max_price
- Date inputs: earliestDeparture, latestDeparture
- Multi-select: nyc_airports (checkbox group)
- Single select: destination_airport (combobox)
- Boolean: nonstop_required, auto_book_enabled
- Complex: preferred_payment_method_id (Stripe integration)
```

### Current Conditional Logic Examples
```typescript
// Examples of complex conditional behavior:

// 1. Auto-booking fields only shown when enabled
const showAutoBooking = watchedFields.auto_book_enabled;

// 2. Payment method required only for auto-booking
const paymentRequired = watchedFields.auto_book_enabled;

// 3. Progressive steps in auto mode
const showStep2 = mode === 'auto' && currentStep === 2;

// 4. NYC airports vs other airport logic
const hasNycAirports = data.nyc_airports?.length > 0;
const hasOtherAirport = !!data.other_departure_airport;
const validDeparture = hasNycAirports || hasOtherAirport;

// 5. Destination validation
const hasDestination = !!data.destination_airport || !!data.destination_other;
```

### Current Error Handling Patterns
```typescript
// Error handling across the application:

// 1. Client-side validation errors (Zod)
const errors = form.formState.errors;

// 2. API submission errors
try {
  await createTripRequest(data);
} catch (error) {
  const errorResponse = handleError(error, { operation: 'createTripRequest' });
  toast({
    title: "Error",
    description: errorResponse.userMessage || errorResponse.message,
    variant: "destructive",
  });
}

// 3. Business logic errors
if (data.auto_book_enabled && !data.preferred_payment_method_id) {
  throw new BusinessLogicError(
    ErrorCode.VALIDATION_ERROR,
    'Auto-booking requires payment method'
  );
}
```

### Current State Management Pattern
```typescript
// Form state is managed through React Hook Form:
const form = useForm<FormValues>({
  resolver: zodResolver(tripFormSchema),
  defaultValues: { /* ... */ },
  mode: 'onChange', // Real-time validation
});

// Global state through React Query for API data:
const { data: paymentMethods } = useQuery({
  queryKey: ['paymentMethods', userId],
  queryFn: fetchPaymentMethods,
});

// Local state for UI behavior:
const [currentStep, setCurrentStep] = useState<1 | 2>(1);
const [isSubmitting, setIsSubmitting] = useState(false);
```

### Current Testing Approach
```typescript
// Testing patterns that new architecture should support:

// 1. Form validation testing
it('should validate required fields', async () => {
  render(<TripRequestForm />);
  const submitButton = screen.getByRole('button', { name: /search/i });
  fireEvent.click(submitButton);
  expect(await screen.findByText('Destination is required')).toBeInTheDocument();
});

// 2. Conditional rendering testing
it('should show payment fields when auto-booking enabled', () => {
  render(<TripRequestForm mode="auto" />);
  const autoBookingToggle = screen.getByRole('checkbox', { name: /auto-book/i });
  fireEvent.click(autoBookingToggle);
  expect(screen.getByLabelText('Payment Method')).toBeInTheDocument();
});

// 3. Multi-step flow testing
it('should progress through steps in auto mode', () => {
  render(<TripRequestForm mode="auto" />);
  const continueButton = screen.getByRole('button', { name: /continue/i });
  fireEvent.click(continueButton);
  expect(screen.getByText('Price & Payment')).toBeInTheDocument();
});
```

## Integration Requirements

### External API Constraints
```typescript
// APIs expect specific data formats:

// 1. Amadeus API format
interface AmadeusSearchParams {
  originLocationCode: string;    // IATA code (e.g., "JFK")
  destinationLocationCode: string;
  departureDate: string;         // ISO date
  returnDate?: string;
  adults: number;
  travelClass: 'ECONOMY' | 'BUSINESS' | 'FIRST';
  nonStop: boolean;
}

// 2. Duffel API format
interface DuffelOfferRequest {
  slices: {
    origin: string;
    destination: string;
    departure_date: string;
  }[];
  passengers: {
    type: 'adult' | 'child' | 'infant_without_seat';
  }[];
  cabin_class: 'economy' | 'premium_economy' | 'business' | 'first';
}

// 3. Database insert format
interface TripRequestInsert {
  user_id: string;
  destination_airport: string;
  departure_airports: string[];
  earliest_departure: string;     // ISO timestamp
  latest_departure: string;
  min_duration: number;
  max_duration: number;
  budget: number;
  nonstop_required: boolean;
  auto_book_enabled: boolean;
}
```

### Accessibility Requirements
```typescript
// Current accessibility patterns to maintain:

// 1. Proper form labeling
<FormLabel htmlFor="max_price_input">Top price you'll pay</FormLabel>
<Input id="max_price_input" aria-describedby="price-help" />

// 2. Error announcements
<FormMessage role="alert">{errors.max_price?.message}</FormMessage>

// 3. Focus management in progressive forms
const handleStepChange = () => {
  requestAnimationFrame(() => {
    const firstInput = document.querySelector('input[data-step="2"]');
    firstInput?.focus();
  });
};

// 4. Screen reader friendly validation
<div aria-live="polite" aria-atomic="true">
  {isSubmitting ? "Processing your request..." : ""}
</div>
```

### Mobile-Specific Considerations
```typescript
// Mobile UX patterns currently implemented:

// 1. Responsive layout changes
const isMobile = useIsMobile();
const gridCols = isMobile ? 'grid-cols-1' : 'lg:grid-cols-2';

// 2. Touch-friendly inputs
<Input 
  type="number" 
  inputMode="numeric"     // Mobile numeric keypad
  className="h-11"        // Larger touch targets
/>

// 3. Mobile-optimized date picker
<DatePicker 
  mode="single"
  disabled={(date) => date < new Date()}
  className="mobile-calendar" // Custom mobile styling
/>

// 4. Sticky form actions
<StickyFormActions 
  className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 md:relative md:border-0"
/>
```

---

**Research Timeline**: 1-2 days for comprehensive analysis
**Implementation Priority**: High (blocking product iteration speed)
**Budget Constraints**: Prefer open-source solutions, minimal new dependencies
