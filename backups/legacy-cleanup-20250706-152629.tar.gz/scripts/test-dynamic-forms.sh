#!/bin/bash

# Dynamic Forms Test Runner
# Runs comprehensive tests for the dynamic forms system

echo "🧪 Running Dynamic Forms Test Suite"
echo "====================================="

# Set environment
export NODE_ENV=test

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
  local color=$1
  local message=$2
  echo -e "${color}${message}${NC}"
}

# Check if required dependencies are installed
print_status $BLUE "Checking dependencies..."
if ! command -v npm &> /dev/null; then
  print_status $RED "❌ npm is required but not installed"
  exit 1
fi

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
  print_status $YELLOW "📦 Installing dependencies..."
  npm install
fi

# Run different test suites
print_status $BLUE "🔧 Running unit tests..."
npx vitest run --config vitest.dynamic-forms.config.ts

# Check exit code
if [ $? -eq 0 ]; then
  print_status $GREEN "✅ Unit tests passed!"
else
  print_status $RED "❌ Unit tests failed!"
  exit 1
fi

# Run coverage report
print_status $BLUE "📊 Generating coverage report..."
npx vitest run --coverage --config vitest.dynamic-forms.config.ts

# Run type checking
print_status $BLUE "🔍 Type checking..."
npx tsc --noEmit --project tsconfig.json

if [ $? -eq 0 ]; then
  print_status $GREEN "✅ Type checking passed!"
else
  print_status $RED "❌ Type checking failed!"
  exit 1
fi

# Run linting
print_status $BLUE "🧹 Linting code..."
npx eslint src/components/forms/**/*.{ts,tsx} src/hooks/**/*.ts src/lib/form-validation.ts src/services/form-config.service.ts src/stores/**/*.ts --fix

if [ $? -eq 0 ]; then
  print_status $GREEN "✅ Linting passed!"
else
  print_status $YELLOW "⚠️  Linting found issues (auto-fixed where possible)"
fi

# Performance benchmarks
print_status $BLUE "⚡ Running performance benchmarks..."
node scripts/benchmark-forms.js

print_status $GREEN "🎉 All tests completed successfully!"
print_status $BLUE "📄 Coverage report available at: coverage/index.html"

echo ""
print_status $BLUE "Test Summary:"
echo "- Unit tests: ✅"
echo "- Type checking: ✅"
echo "- Code coverage: Available in coverage/ directory"
echo "- Performance benchmarks: Completed"
echo ""
print_status $GREEN "Dynamic forms system is ready for deployment! 🚀"
