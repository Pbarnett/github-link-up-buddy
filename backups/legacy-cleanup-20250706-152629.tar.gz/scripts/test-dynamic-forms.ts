/**
 * Test Script for Dynamic Forms System
 * 
 * This script tests the complete dynamic forms functionality
 */

import { createClient } from '@supabase/supabase-js';
import type { FormConfiguration } from '../src/types/dynamic-forms';

// Initialize Supabase client
const supabaseUrl = process.env.VITE_SUPABASE_URL!;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Sample form configuration for testing
const sampleFlightSearchForm: FormConfiguration = {
  id: crypto.randomUUID(),
  name: 'flight-search-test',
  version: 1,
  sections: [
    {
      id: 'travel-details',
      title: 'Travel Details',
      description: 'Enter your travel information',
      fields: [
        {
          id: 'origin',
          type: 'airport-autocomplete',
          label: 'From',
          placeholder: 'Enter departure city or airport',
          validation: {
            required: true,
            message: 'Please select a departure airport'
          },
          apiIntegration: {
            endpoint: 'https://api.example.com/airports',
            method: 'GET',
            securityLevel: 'medium'
          }
        },
        {
          id: 'destination',
          type: 'airport-autocomplete',
          label: 'To',
          placeholder: 'Enter destination city or airport',
          validation: {
            required: true,
            message: 'Please select a destination airport'
          }
        },
        {
          id: 'departure-date',
          type: 'date',
          label: 'Departure Date',
          validation: {
            required: true,
            message: 'Please select a departure date'
          }
        },
        {
          id: 'return-date',
          type: 'date',
          label: 'Return Date',
          conditional: {
            showWhen: {
              field: 'trip-type',
              operator: 'equals',
              value: 'round-trip'
            }
          }
        },
        {
          id: 'trip-type',
          type: 'radio',
          label: 'Trip Type',
          defaultValue: 'round-trip',
          options: [
            { label: 'Round Trip', value: 'round-trip' },
            { label: 'One Way', value: 'one-way' }
          ],
          validation: {
            required: true
          }
        },
        {
          id: 'passengers',
          type: 'number',
          label: 'Passengers',
          defaultValue: 1,
          validation: {
            required: true,
            min: 1,
            max: 9,
            message: 'Please select 1-9 passengers'
          }
        }
      ]
    },
    {
      id: 'preferences',
      title: 'Preferences',
      description: 'Customize your search preferences',
      fields: [
        {
          id: 'cabin-class',
          type: 'select',
          label: 'Cabin Class',
          defaultValue: 'economy',
          options: [
            { label: 'Economy', value: 'economy' },
            { label: 'Premium Economy', value: 'premium_economy' },
            { label: 'Business', value: 'business' },
            { label: 'First Class', value: 'first' }
          ]
        },
        {
          id: 'nonstop-only',
          type: 'switch',
          label: 'Non-stop flights only',
          defaultValue: false
        },
        {
          id: 'max-price',
          type: 'number',
          label: 'Maximum Price (USD)',
          placeholder: 'Enter maximum price',
          validation: {
            min: 0,
            message: 'Price must be greater than 0'
          }
        },
        {
          id: 'preferred-airlines',
          type: 'multi-select',
          label: 'Preferred Airlines',
          description: 'Select your preferred airlines (optional)',
          options: [
            { label: 'American Airlines', value: 'AA' },
            { label: 'Delta Air Lines', value: 'DL' },
            { label: 'United Airlines', value: 'UA' },
            { label: 'Southwest Airlines', value: 'WN' },
            { label: 'JetBlue Airways', value: 'B6' }
          ]
        }
      ]
    },
    {
      id: 'auto-booking',
      title: 'Auto-Booking',
      description: 'Set up automatic booking when criteria are met',
      fields: [
        {
          id: 'enable-auto-booking',
          type: 'switch',
          label: 'Enable Auto-Booking',
          description: 'Automatically book flights when they meet your criteria',
          defaultValue: false
        },
        {
          id: 'price-threshold',
          type: 'number',
          label: 'Price Threshold (USD)',
          placeholder: 'Auto-book when price drops below this amount',
          conditional: {
            showWhen: {
              field: 'enable-auto-booking',
              operator: 'equals',
              value: true
            }
          },
          validation: {
            required: true,
            min: 1,
            message: 'Please enter a valid price threshold'
          }
        }
      ]
    }
  ],
  integrations: {
    onSubmit: {
      endpoint: 'https://api.parkerflight.com/v1/flight-search',
      method: 'POST',
      securityLevel: 'high',
      timeout: 30000
    }
  },
  metadata: {
    created: new Date().toISOString(),
    description: 'Flight search form for Parker Flight application',
    category: 'flight-search'
  }
};

async function testDynamicFormsSystem() {
  console.log('🚀 Testing Dynamic Forms System...\n');

  try {
    // Test 1: Create form configuration
    console.log('1. Testing form configuration creation...');
    const createResponse = await supabase.functions.invoke('form-config-manager', {
      body: {
        action: 'create',
        formData: sampleFlightSearchForm
      }
    });

    if (createResponse.error) {
      throw new Error(`Create failed: ${createResponse.error.message}`);
    }

    console.log('✅ Form configuration created successfully');
    const configId = createResponse.data.data.config.id;
    console.log(`   Config ID: ${configId}\n`);

    // Test 2: Validate form configuration
    console.log('2. Testing form validation...');
    const validationResponse = await supabase.functions.invoke('form-schema-validator', {
      body: {
        config: sampleFlightSearchForm,
        validationLevel: 'comprehensive',
        includePerformanceMetrics: true
      }
    });

    if (validationResponse.error) {
      throw new Error(`Validation failed: ${validationResponse.error.message}`);
    }

    console.log('✅ Form validation completed');
    console.log(`   Valid: ${validationResponse.data.isValid}`);
    console.log(`   Violations: ${validationResponse.data.validationResults.violations.length}`);
    console.log(`   Suggestions: ${validationResponse.data.suggestions?.length || 0}`);
    
    if (validationResponse.data.performanceMetrics) {
      console.log(`   Performance - Fields: ${validationResponse.data.performanceMetrics.fieldCount}, Complexity: ${validationResponse.data.performanceMetrics.complexityScore}`);
    }
    console.log();

    // Test 3: Get form configuration
    console.log('3. Testing form retrieval...');
    const getResponse = await supabase.functions.invoke('form-config-manager', {
      body: {
        action: 'get',
        configId
      }
    });

    if (getResponse.error) {
      throw new Error(`Get failed: ${getResponse.error.message}`);
    }

    console.log('✅ Form configuration retrieved successfully');
    console.log(`   Name: ${getResponse.data.data.config.name}`);
    console.log(`   Status: ${getResponse.data.data.config.status}\n`);

    // Test 4: Update form configuration
    console.log('4. Testing form configuration update...');
    const updatedForm = {
      ...sampleFlightSearchForm,
      metadata: {
        ...sampleFlightSearchForm.metadata,
        updated: new Date().toISOString(),
        description: 'Updated flight search form for Parker Flight application'
      }
    };

    const updateResponse = await supabase.functions.invoke('form-config-manager', {
      body: {
        action: 'update',
        configId,
        formData: updatedForm
      }
    });

    if (updateResponse.error) {
      throw new Error(`Update failed: ${updateResponse.error.message}`);
    }

    console.log('✅ Form configuration updated successfully\n');

    // Test 5: List form configurations
    console.log('5. Testing form configuration listing...');
    const listResponse = await supabase.functions.invoke('form-config-manager', {
      body: {
        action: 'list'
      }
    });

    if (listResponse.error) {
      throw new Error(`List failed: ${listResponse.error.message}`);
    }

    console.log('✅ Form configurations listed successfully');
    console.log(`   Total configurations: ${listResponse.data.data.configurations.length}\n`);

    // Test 6: Deploy form configuration
    console.log('6. Testing form configuration deployment...');
    const deployResponse = await supabase.functions.invoke('form-config-manager', {
      body: {
        action: 'deploy',
        configId,
        deploymentOptions: {
          strategy: 'immediate'
        }
      }
    });

    if (deployResponse.error) {
      throw new Error(`Deploy failed: ${deployResponse.error.message}`);
    }

    console.log('✅ Form configuration deployed successfully');
    console.log(`   Deployment ID: ${deployResponse.data.data.deployment.id}\n`);

    // Test 7: Get configuration by name (active deployment)
    console.log('7. Testing retrieval by name...');
    const getByNameResponse = await supabase.functions.invoke('form-config-manager', {
      body: {
        action: 'get',
        configName: sampleFlightSearchForm.name
      }
    });

    if (getByNameResponse.error) {
      throw new Error(`Get by name failed: ${getByNameResponse.error.message}`);
    }

    console.log('✅ Form configuration retrieved by name successfully');
    console.log(`   Status: ${getByNameResponse.data.data.config.status}\n`);

    // Test 8: Test analytics logging
    console.log('8. Testing analytics logging...');
    const analyticsResult = await supabase.rpc('log_form_usage', {
      p_config_id: configId,
      p_user_id: null,
      p_session_id: 'test-session-123',
      p_event_type: 'view',
      p_field_id: null,
      p_event_data: { test: true },
      p_load_time_ms: 250,
      p_ip_address: '127.0.0.1',
      p_user_agent: 'Test Script'
    });

    console.log('✅ Analytics logging completed successfully\n');

    // Test 9: Clean up - Archive the test configuration
    console.log('9. Testing form configuration cleanup...');
    const deleteResponse = await supabase.functions.invoke('form-config-manager', {
      body: {
        action: 'delete',
        configId
      }
    });

    if (deleteResponse.error) {
      throw new Error(`Delete failed: ${deleteResponse.error.message}`);
    }

    console.log('✅ Form configuration archived successfully\n');

    console.log('🎉 All tests passed! Dynamic Forms System is working correctly.');

  } catch (error) {
    console.error('❌ Test failed:', error.message);
    process.exit(1);
  }
}

// Additional test for KMS functionality
async function testKMSIntegration() {
  console.log('\n🔐 Testing KMS Integration...\n');

  try {
    // Create a form with sensitive data
    const sensitiveForm: FormConfiguration = {
      ...sampleFlightSearchForm,
      id: crypto.randomUUID(),
      name: 'payment-form-test',
      stripeConfig: {
        publishableKey: 'pk_test_example_key',
        appearance: {
          theme: 'stripe'
        }
      },
      apiKeys: {
        stripeSecret: 'sk_test_example_secret'
      },
      sections: [
        ...sampleFlightSearchForm.sections,
        {
          id: 'payment',
          title: 'Payment Information',
          fields: [
            {
              id: 'stripe-card',
              type: 'stripe-card',
              label: 'Credit Card',
              validation: {
                required: true
              },
              stripeConfig: {
                appearance: {
                  theme: 'stripe'
                }
              }
            }
          ]
        }
      ]
    };

    const response = await supabase.functions.invoke('form-config-manager', {
      body: {
        action: 'create',
        formData: sensitiveForm
      }
    });

    if (response.error) {
      throw new Error(`KMS test failed: ${response.error.message}`);
    }

    console.log('✅ KMS encryption test passed');
    console.log(`   Sensitive data encrypted and stored securely`);

    // Clean up
    const configId = response.data.data.config.id;
    await supabase.functions.invoke('form-config-manager', {
      body: {
        action: 'delete',
        configId
      }
    });

    console.log('✅ KMS test cleanup completed\n');

  } catch (error) {
    console.error('❌ KMS test failed:', error.message);
  }
}

// Run tests
async function runAllTests() {
  await testDynamicFormsSystem();
  await testKMSIntegration();
}

// Execute if run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runAllTests();
}

export { testDynamicFormsSystem, testKMSIntegration };
