/**
 * Dynamic Forms Demo Page
 * 
 * Showcases the completed dynamic forms system with live examples
 */

import { DynamicFormsExample } from '@/components/forms/examples/DynamicFormsExample';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart3, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function DynamicForms() {
  const navigate = useNavigate();

  return (
    <div className="space-y-6">
      {/* Navigation Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Dynamic Forms System
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-2">
                Complete dynamic forms system with analytics tracking
              </p>
              <div className="flex gap-2">
                <Button 
                  onClick={() => navigate('/form-analytics')}
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-2"
                >
                  <BarChart3 className="h-4 w-4" />
                  View Analytics Dashboard
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Dynamic Forms Example */}
      <DynamicFormsExample />
    </div>
  );
}
