/**
 * Dynamic Forms Performance Benchmarks
 * 
 * Benchmark tests to ensure dynamic forms meet performance requirements
 * - Form rendering under 100ms
 * - Field validation under 50ms
 * - Configuration processing under 200ms
 */

import React from 'react';
import { bench, describe } from 'vitest';
import { render } from '@testing-library/react';
import { FormProvider, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';

import { DynamicFormRenderer } from '@/components/forms/DynamicFormRenderer';
import { DynamicFieldRenderer } from '@/components/forms/fields/DynamicFieldRenderer';
import { generateValidationSchema, validateFormData } from '@/lib/form-validation';
import { evaluateConditionalLogic } from '@/lib/conditional-logic';
import type { DynamicFormConfig, FieldConfiguration } from '@/types/dynamic-forms';

// Test data generators
const generateLargeFormConfig = (fieldCount: number): DynamicFormConfig => {
  const fields: FieldConfiguration[] = [];
  
  for (let i = 0; i < fieldCount; i++) {
    fields.push({
      id: `field_${i}`,
      type: 'text',
      label: `Field ${i}`,
      placeholder: `Enter value for field ${i}`,
      required: i % 3 === 0,
      validation: {
        required: i % 3 === 0,
        minLength: 2,
        maxLength: 100
      }
    });
  }

  return {
    id: 'performance_test_form',
    name: 'Performance Test Form',
    title: 'Performance Test Form',
    version: 1,
    sections: [
      {
        id: 'section_1',
        title: 'Test Section',
        description: 'Performance testing section',
        fields
      }
    ]
  };
};

const generateComplexFormConfig = (): DynamicFormConfig => ({
  id: 'complex_form',
  name: 'Complex Form',
  title: 'Complex Performance Test Form',
  version: 1,
  sections: [
    {
      id: 'basic_info',
      title: 'Basic Information',
      fields: [
        {
          id: 'name',
          type: 'text',
          label: 'Name',
          required: true,
          validation: { required: true, minLength: 2 }
        },
        {
          id: 'email',
          type: 'email',
          label: 'Email',
          required: true,
          validation: { required: true, email: true }
        },
        {
          id: 'phone',
          type: 'phone',
          label: 'Phone',
          validation: { phone: true }
        }
      ]
    },
    {
      id: 'preferences',
      title: 'Preferences',
      fields: [
        {
          id: 'newsletter',
          type: 'checkbox',
          label: 'Subscribe to newsletter'
        },
        {
          id: 'frequency',
          type: 'select',
          label: 'Newsletter frequency',
          options: [
            { label: 'Daily', value: 'daily' },
            { label: 'Weekly', value: 'weekly' },
            { label: 'Monthly', value: 'monthly' }
          ],
          conditional: {
            showWhen: { field: 'newsletter', operator: 'equals', value: true }
          }
        },
        {
          id: 'categories',
          type: 'multi-select',
          label: 'Interested categories',
          options: [
            { label: 'Technology', value: 'tech' },
            { label: 'Travel', value: 'travel' },
            { label: 'Business', value: 'business' },
            { label: 'Sports', value: 'sports' },
            { label: 'Entertainment', value: 'entertainment' }
          ]
        }
      ]
    },
    {
      id: 'travel_info',
      title: 'Travel Information',
      fields: [
        {
          id: 'departure_airport',
          type: 'airport-autocomplete',
          label: 'Departure Airport',
          validation: { required: true }
        },
        {
          id: 'arrival_airport',
          type: 'airport-autocomplete',
          label: 'Arrival Airport',
          validation: { required: true }
        },
        {
          id: 'departure_date',
          type: 'date',
          label: 'Departure Date',
          validation: { required: true }
        },
        {
          id: 'return_date',
          type: 'date',
          label: 'Return Date',
          conditional: {
            showWhen: { field: 'trip_type', operator: 'equals', value: 'round-trip' }
          }
        },
        {
          id: 'passengers',
          type: 'number',
          label: 'Number of Passengers',
          validation: { required: true, min: 1, max: 9 }
        },
        {
          id: 'cabin_class',
          type: 'select',
          label: 'Cabin Class',
          options: [
            { label: 'Economy', value: 'economy' },
            { label: 'Premium Economy', value: 'premium_economy' },
            { label: 'Business', value: 'business' },
            { label: 'First Class', value: 'first' }
          ],
          validation: { required: true }
        }
      ]
    }
  ]
});

const generateFormData = (config: DynamicFormConfig): Record<string, any> => {
  const data: Record<string, any> = {};
  
  config.sections.forEach(section => {
    section.fields.forEach(field => {
      switch (field.type) {
        case 'text':
        case 'email':
          data[field.id] = 'test@example.com';
          break;
        case 'number':
          data[field.id] = 1;
          break;
        case 'checkbox':
          data[field.id] = true;
          break;
        case 'select':
          data[field.id] = field.options?.[0]?.value || 'option1';
          break;
        case 'multi-select':
          data[field.id] = [field.options?.[0]?.value || 'option1'];
          break;
        case 'date':
          data[field.id] = new Date().toISOString().split('T')[0];
          break;
        default:
          data[field.id] = 'test value';
      }
    });
  });
  
  return data;
};

// Mock form wrapper for testing
const FormWrapper = ({ 
  children, 
  config 
}: {
  children: React.ReactNode;
  config: DynamicFormConfig;
}) => {
  const schema = generateValidationSchema(config);
  const form = useForm({
    resolver: zodResolver(schema),
    defaultValues: {}
  });

  return (
    <FormProvider {...form}>
      {children}
    </FormProvider>
  );
};

describe('Dynamic Forms Performance', () => {
  describe('Form Rendering Performance', () => {
    bench('render small form (10 fields)', () => {
      const config = generateLargeFormConfig(10);
      render(
        <FormWrapper config={config}>
          <DynamicFormRenderer
            configuration={config}
            onSubmit={() => {}}
          />
        </FormWrapper>
      );
    });

    bench('render medium form (25 fields)', () => {
      const config = generateLargeFormConfig(25);
      render(
        <FormWrapper config={config}>
          <DynamicFormRenderer
            configuration={config}
            onSubmit={() => {}}
          />
        </FormWrapper>
      );
    });

    bench('render large form (50 fields)', () => {
      const config = generateLargeFormConfig(50);
      render(
        <FormWrapper config={config}>
          <DynamicFormRenderer
            configuration={config}
            onSubmit={() => {}}
          />
        </FormWrapper>
      );
    });

    bench('render complex form with conditional logic', () => {
      const config = generateComplexFormConfig();
      render(
        <FormWrapper config={config}>
          <DynamicFormRenderer
            configuration={config}
            onSubmit={() => {}}
          />
        </FormWrapper>
      );
    });
  });

  describe('Field Rendering Performance', () => {
    bench('render text field', () => {
      const field: FieldConfiguration = {
        id: 'test_field',
        type: 'text',
        label: 'Test Field',
        validation: { required: true }
      };

      render(
        <DynamicFieldRenderer
          field={field}
          value=""
          onChange={() => {}}
        />
      );
    });

    bench('render select field with many options', () => {
      const options = Array.from({ length: 100 }, (_, i) => ({
        label: `Option ${i + 1}`,
        value: `option_${i + 1}`
      }));

      const field: FieldConfiguration = {
        id: 'test_select',
        type: 'select',
        label: 'Test Select',
        options,
        validation: { required: true }
      };

      render(
        <DynamicFieldRenderer
          field={field}
          value=""
          onChange={() => {}}
        />
      );
    });

    bench('render multi-select field with many options', () => {
      const options = Array.from({ length: 50 }, (_, i) => ({
        label: `Option ${i + 1}`,
        value: `option_${i + 1}`
      }));

      const field: FieldConfiguration = {
        id: 'test_multi_select',
        type: 'multi-select',
        label: 'Test Multi Select',
        options,
        validation: { required: true }
      };

      render(
        <DynamicFieldRenderer
          field={field}
          value={[]}
          onChange={() => {}}
        />
      );
    });
  });

  describe('Validation Performance', () => {
    bench('generate validation schema for small form', () => {
      const config = generateLargeFormConfig(10);
      generateValidationSchema(config);
    });

    bench('generate validation schema for large form', () => {
      const config = generateLargeFormConfig(50);
      generateValidationSchema(config);
    });

    bench('validate form data - small form', async () => {
      const config = generateLargeFormConfig(10);
      const data = generateFormData(config);
      await validateFormData(config, data);
    });

    bench('validate form data - large form', async () => {
      const config = generateLargeFormConfig(50);
      const data = generateFormData(config);
      await validateFormData(config, data);
    });

    bench('validate complex form with conditional logic', async () => {
      const config = generateComplexFormConfig();
      const data = generateFormData(config);
      await validateFormData(config, data);
    });
  });

  describe('Conditional Logic Performance', () => {
    bench('evaluate simple conditional logic', () => {
      const logic = {
        showWhen: { field: 'test_field', operator: 'equals' as const, value: 'show' }
      };
      const formData = { test_field: 'show' };
      evaluateConditionalLogic(logic, formData);
    });

    bench('evaluate complex conditional logic', () => {
      const logic = {
        showWhen: { field: 'field1', operator: 'equals' as const, value: 'show' },
        hideWhen: { field: 'field2', operator: 'not_equals' as const, value: 'hide' },
        enableWhen: { field: 'field3', operator: 'oneOf' as const, value: ['a', 'b', 'c'] },
        disableWhen: { field: 'field4', operator: 'greater' as const, value: 10 }
      };
      const formData = { 
        field1: 'show', 
        field2: 'visible', 
        field3: 'a', 
        field4: 5 
      };
      evaluateConditionalLogic(logic, formData);
    });

    bench('evaluate conditional logic for 20 fields', () => {
      const formData: Record<string, any> = {};
      for (let i = 0; i < 20; i++) {
        const logic = {
          showWhen: { field: `trigger_${i}`, operator: 'equals' as const, value: true }
        };
        formData[`trigger_${i}`] = i % 2 === 0;
        evaluateConditionalLogic(logic, formData);
      }
    });
  });

  describe('Memory Performance', () => {
    bench('create and destroy large form instances', () => {
      // Test memory allocation/deallocation patterns
      const configs = [];
      for (let i = 0; i < 10; i++) {
        configs.push(generateLargeFormConfig(20));
      }
      
      // Simulate cleanup
      configs.length = 0;
    });

    bench('process large form configurations', () => {
      const config = generateLargeFormConfig(100);
      const schema = generateValidationSchema(config);
      const data = generateFormData(config);
      
      // Simulate form processing
      config.sections.forEach(section => {
        section.fields.forEach(field => {
          if (field.conditional) {
            evaluateConditionalLogic(field.conditional, data);
          }
        });
      });
    });
  });
});

// Export performance utilities
export const performanceUtils = {
  generateLargeFormConfig,
  generateComplexFormConfig,
  generateFormData,
  FormWrapper
};
