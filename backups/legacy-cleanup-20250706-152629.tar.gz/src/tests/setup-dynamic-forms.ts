/**
 * Dynamic Forms Test Setup
 * 
 * Global test setup for dynamic forms system
 */

import '@testing-library/jest-dom';
import { vi } from 'vitest';
import { cleanup } from '@testing-library/react';
import { afterEach, beforeAll, afterAll } from 'vitest';

// Clean up after each test
afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});

// Mock window.crypto for tests
beforeAll(() => {
  Object.defineProperty(window, 'crypto', {
    value: {
      randomUUID: () => 'test-uuid-' + Math.random().toString(36).substring(2, 15)
    }
  });

  // Mock IntersectionObserver
  global.IntersectionObserver = vi.fn(() => ({
    disconnect: vi.fn(),
    observe: vi.fn(),
    unobserve: vi.fn(),
  })) as any;

  // Mock ResizeObserver
  global.ResizeObserver = vi.fn(() => ({
    disconnect: vi.fn(),
    observe: vi.fn(),
    unobserve: vi.fn(),
  })) as any;

  // Mock matchMedia
  Object.defineProperty(window, 'matchMedia', {
    writable: true,
    value: vi.fn().mockImplementation(query => ({
      matches: false,
      media: query,
      onchange: null,
      addListener: vi.fn(), // deprecated
      removeListener: vi.fn(), // deprecated
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
      dispatchEvent: vi.fn(),
    })),
  });

  // Mock sessionStorage
  const mockStorage = {
    getItem: vi.fn(),
    setItem: vi.fn(),
    removeItem: vi.fn(),
    clear: vi.fn(),
  };
  Object.defineProperty(window, 'sessionStorage', {
    value: mockStorage
  });
  Object.defineProperty(window, 'localStorage', {
    value: mockStorage
  });
});

// Global test utilities
export const createMockFormConfiguration = (overrides = {}) => ({
  id: 'test-form-id',
  name: 'Test Form',
  version: 1,
  sections: [
    {
      id: 'test-section',
      title: 'Test Section',
      description: 'Test section description',
      fields: [
        {
          id: 'test-field',
          type: 'text',
          label: 'Test Field',
          placeholder: 'Enter test value',
          validation: { required: true }
        }
      ]
    }
  ],
  ...overrides
});

export const createMockFieldConfiguration = (overrides = {}) => ({
  id: 'test-field',
  type: 'text',
  label: 'Test Field',
  placeholder: 'Enter value',
  validation: { required: false },
  ...overrides
});

export const createMockFormState = (overrides = {}) => ({
  values: {},
  errors: {},
  touched: {},
  isSubmitting: false,
  isValid: true,
  ...overrides
});

// Mock Supabase
export const mockSupabase = {
  functions: {
    invoke: vi.fn().mockResolvedValue({ data: null, error: null })
  },
  from: vi.fn(() => ({
    select: vi.fn().mockReturnThis(),
    insert: vi.fn().mockReturnThis(),
    update: vi.fn().mockReturnThis(),
    delete: vi.fn().mockReturnThis(),
    eq: vi.fn().mockReturnThis(),
    single: vi.fn().mockResolvedValue({ data: null, error: null })
  })),
  auth: {
    getUser: vi.fn().mockResolvedValue({ data: { user: null }, error: null })
  },
  rpc: vi.fn().mockResolvedValue({ data: null, error: null })
};

// Mock the form config service
vi.mock('@/services/form-config.service', () => ({
  formConfigService: {
    getConfiguration: vi.fn().mockResolvedValue({
      success: true,
      data: {
        config: {
          id: 'test-config',
          config_data: createMockFormConfiguration()
        }
      }
    }),
    getConfigurationByName: vi.fn().mockResolvedValue({
      success: true,
      data: {
        config: {
          id: 'test-config',
          config_data: createMockFormConfiguration()
        }
      }
    }),
    createConfiguration: vi.fn().mockResolvedValue({
      success: true,
      data: {
        config: {
          id: 'new-config',
          config_data: createMockFormConfiguration()
        }
      }
    }),
    updateConfiguration: vi.fn().mockResolvedValue({
      success: true,
      data: {
        config: {
          id: 'test-config',
          config_data: createMockFormConfiguration()
        }
      }
    }),
    validateConfiguration: vi.fn().mockResolvedValue({
      success: true,
      validationResults: {
        isSecure: true,
        violations: [],
        recommendations: []
      }
    }),
    logUsageAnalytics: vi.fn().mockResolvedValue(undefined)
  }
}));

// Mock the form store
vi.mock('@/stores/useFormStore', () => ({
  useFormStore: vi.fn(() => ({
    configurations: new Map(),
    loading: {
      configurations: false,
      deployment: false,
      validation: false,
      analytics: false
    },
    errors: {
      configuration: null,
      deployment: null,
      validation: null,
      analytics: null
    },
    loadConfiguration: vi.fn(),
    validateConfiguration: vi.fn().mockResolvedValue({
      isSecure: true,
      violations: [],
      recommendations: []
    }),
    createConfiguration: vi.fn(),
    updateConfiguration: vi.fn(),
    deleteConfiguration: vi.fn()
  }))
}));

// Export test utilities
export { vi, cleanup };
