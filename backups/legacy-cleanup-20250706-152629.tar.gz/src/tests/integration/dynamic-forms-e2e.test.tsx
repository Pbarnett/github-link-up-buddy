/**
 * Dynamic Forms End-to-End Integration Tests
 * 
 * Tests the complete flow from form configuration to rendering and submission
 * Includes tests for form builder, validation, conditional logic, and analytics
 */

import React from 'react';
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { axe, toHaveNoViolations } from 'jest-axe';

import { DynamicFormRenderer } from '@/components/forms/DynamicFormRenderer';
import { FormBuilder } from '@/components/forms/FormBuilder';
import { formConfigService } from '@/services/form-config.service';
import { useFormStore } from '@/stores/useFormStore';
import type { DynamicFormConfig, FormSubmission } from '@/types/dynamic-forms';

// Extend Jest matchers
expect.extend(toHaveNoViolations);

// Mock services
vi.mock('@/services/form-config.service', () => ({
  formConfigService: {
    getConfiguration: vi.fn(),
    createConfiguration: vi.fn(),
    updateConfiguration: vi.fn(),
    validateConfiguration: vi.fn(),
    logAnalytics: vi.fn(),
    logUsageAnalytics: vi.fn()
  }
}));

// Test form configurations
const simpleFormConfig: DynamicFormConfig = {
  id: 'simple_test_form',
  name: 'Simple Test Form',
  title: 'Simple Test Form',
  version: 1,
  sections: [
    {
      id: 'basic_info',
      title: 'Basic Information',
      description: 'Please provide your basic information',
      fields: [
        {
          id: 'name',
          type: 'text',
          label: 'Full Name',
          placeholder: 'Enter your full name',
          required: true,
          validation: {
            required: true,
            minLength: 2,
            message: 'Name must be at least 2 characters'
          }
        },
        {
          id: 'email',
          type: 'email',
          label: 'Email Address',
          placeholder: 'Enter your email',
          required: true,
          validation: {
            required: true,
            email: true,
            message: 'Please enter a valid email address'
          }
        },
        {
          id: 'age',
          type: 'number',
          label: 'Age',
          placeholder: 'Enter your age',
          validation: {
            min: 18,
            max: 120,
            message: 'Age must be between 18 and 120'
          }
        }
      ]
    }
  ]
};

const conditionalFormConfig: DynamicFormConfig = {
  id: 'conditional_test_form',
  name: 'Conditional Test Form',
  title: 'Conditional Logic Test Form',
  version: 1,
  sections: [
    {
      id: 'preferences',
      title: 'Preferences',
      fields: [
        {
          id: 'newsletter',
          type: 'checkbox',
          label: 'Subscribe to Newsletter'
        },
        {
          id: 'frequency',
          type: 'select',
          label: 'Newsletter Frequency',
          options: [
            { label: 'Daily', value: 'daily' },
            { label: 'Weekly', value: 'weekly' },
            { label: 'Monthly', value: 'monthly' }
          ],
          conditional: {
            showWhen: { field: 'newsletter', operator: 'equals', value: true }
          }
        },
        {
          id: 'email_format',
          type: 'select',
          label: 'Email Format',
          options: [
            { label: 'HTML', value: 'html' },
            { label: 'Text', value: 'text' }
          ],
          conditional: {
            showWhen: { field: 'newsletter', operator: 'equals', value: true }
          }
        }
      ]
    }
  ]
};

const complexFormConfig: DynamicFormConfig = {
  id: 'complex_test_form',
  name: 'Complex Test Form',
  title: 'Complex Integration Test Form',
  version: 1,
  sections: [
    {
      id: 'personal_info',
      title: 'Personal Information',
      fields: [
        {
          id: 'first_name',
          type: 'text',
          label: 'First Name',
          required: true,
          validation: { required: true, minLength: 1 }
        },
        {
          id: 'last_name',
          type: 'text',
          label: 'Last Name',
          required: true,
          validation: { required: true, minLength: 1 }
        },
        {
          id: 'phone',
          type: 'phone',
          label: 'Phone Number',
          validation: { phone: true }
        }
      ]
    },
    {
      id: 'travel_preferences',
      title: 'Travel Preferences',
      fields: [
        {
          id: 'departure_city',
          type: 'airport-autocomplete',
          label: 'Departure City',
          required: true,
          validation: { required: true }
        },
        {
          id: 'destination_city',
          type: 'airport-autocomplete',
          label: 'Destination City',
          required: true,
          validation: { required: true }
        },
        {
          id: 'travel_dates',
          type: 'date-range',
          label: 'Travel Dates',
          required: true,
          validation: { required: true }
        },
        {
          id: 'flexible_dates',
          type: 'checkbox',
          label: 'I have flexible dates'
        },
        {
          id: 'date_flexibility',
          type: 'select',
          label: 'Date Flexibility',
          options: [
            { label: '±1 day', value: '1' },
            { label: '±3 days', value: '3' },
            { label: '±1 week', value: '7' }
          ],
          conditional: {
            showWhen: { field: 'flexible_dates', operator: 'equals', value: true }
          }
        }
      ]
    }
  ]
};

describe('Dynamic Forms Integration Tests', () => {
  const user = userEvent.setup();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Form Rendering and Basic Interaction', () => {
    it('should render a complete form from configuration', async () => {
      const onSubmit = vi.fn();

      render(
        <DynamicFormRenderer
          configuration={simpleFormConfig}
          onSubmit={onSubmit}
        />
      );

      // Check form title
      expect(screen.getByText('Simple Test Form')).toBeInTheDocument();

      // Check section title
      expect(screen.getByText('Basic Information')).toBeInTheDocument();

      // Check all fields are rendered
      expect(screen.getByLabelText(/full name/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/email address/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/age/i)).toBeInTheDocument();

      // Check submit button
      expect(screen.getByRole('button', { name: /submit/i })).toBeInTheDocument();
    });

    it('should handle form submission with valid data', async () => {
      const onSubmit = vi.fn();

      render(
        <DynamicFormRenderer
          configuration={simpleFormConfig}
          onSubmit={onSubmit}
        />
      );

      // Fill out the form
      await user.type(screen.getByLabelText(/full name/i), 'John Doe');
      await user.type(screen.getByLabelText(/email address/i), 'john@example.com');
      await user.type(screen.getByLabelText(/age/i), '25');

      // Submit the form
      await user.click(screen.getByRole('button', { name: /submit/i }));

      await waitFor(() => {
        expect(onSubmit).toHaveBeenCalledWith(
          expect.objectContaining({
            formId: 'simple_test_form',
            formVersion: 1,
            data: {
              name: 'John Doe',
              email: 'john@example.com',
              age: 25
            },
            metadata: expect.objectContaining({
              submittedAt: expect.any(String),
              submissionId: expect.any(String)
            })
          })
        );
      });
    });

    it('should show validation errors for invalid data', async () => {
      const onSubmit = vi.fn();

      render(
        <DynamicFormRenderer
          configuration={simpleFormConfig}
          onSubmit={onSubmit}
        />
      );

      // Try to submit without filling required fields
      await user.click(screen.getByRole('button', { name: /submit/i }));

      await waitFor(() => {
        expect(screen.getByText(/name must be at least 2 characters/i)).toBeInTheDocument();
        expect(screen.getByText(/please enter a valid email address/i)).toBeInTheDocument();
      });

      expect(onSubmit).not.toHaveBeenCalled();
    });

    it('should validate email format', async () => {
      const onSubmit = vi.fn();

      render(
        <DynamicFormRenderer
          configuration={simpleFormConfig}
          onSubmit={onSubmit}
        />
      );

      // Fill with invalid email
      await user.type(screen.getByLabelText(/full name/i), 'John Doe');
      await user.type(screen.getByLabelText(/email address/i), 'invalid-email');

      await user.click(screen.getByRole('button', { name: /submit/i }));

      await waitFor(() => {
        expect(screen.getByText(/please enter a valid email address/i)).toBeInTheDocument();
      });

      expect(onSubmit).not.toHaveBeenCalled();
    });
  });

  describe('Conditional Logic Integration', () => {
    it('should show/hide fields based on conditional logic', async () => {
      render(
        <DynamicFormRenderer
          configuration={conditionalFormConfig}
          onSubmit={vi.fn()}
        />
      );

      const newsletterCheckbox = screen.getByLabelText(/subscribe to newsletter/i);
      
      // Initially, conditional fields should not be visible
      expect(screen.queryByLabelText(/newsletter frequency/i)).not.toBeInTheDocument();
      expect(screen.queryByLabelText(/email format/i)).not.toBeInTheDocument();

      // Check the newsletter checkbox
      await user.click(newsletterCheckbox);

      await waitFor(() => {
        expect(screen.getByLabelText(/newsletter frequency/i)).toBeInTheDocument();
        expect(screen.getByLabelText(/email format/i)).toBeInTheDocument();
      });

      // Uncheck the checkbox
      await user.click(newsletterCheckbox);

      await waitFor(() => {
        expect(screen.queryByLabelText(/newsletter frequency/i)).not.toBeInTheDocument();
        expect(screen.queryByLabelText(/email format/i)).not.toBeInTheDocument();
      });
    });

    it('should maintain field values when showing/hiding fields', async () => {
      render(
        <DynamicFormRenderer
          configuration={conditionalFormConfig}
          onSubmit={vi.fn()}
        />
      );

      const newsletterCheckbox = screen.getByLabelText(/subscribe to newsletter/i);
      
      // Check newsletter to show conditional fields
      await user.click(newsletterCheckbox);

      await waitFor(() => {
        expect(screen.getByLabelText(/newsletter frequency/i)).toBeInTheDocument();
      });

      // Select a frequency
      const frequencySelect = screen.getByLabelText(/newsletter frequency/i);
      await user.selectOptions(frequencySelect, 'weekly');

      // Hide fields by unchecking newsletter
      await user.click(newsletterCheckbox);

      await waitFor(() => {
        expect(screen.queryByLabelText(/newsletter frequency/i)).not.toBeInTheDocument();
      });

      // Show fields again
      await user.click(newsletterCheckbox);

      await waitFor(() => {
        const newFrequencySelect = screen.getByLabelText(/newsletter frequency/i);
        expect(newFrequencySelect).toBeInTheDocument();
        // Value should be maintained
        expect(newFrequencySelect).toHaveValue('weekly');
      });
    });
  });

  describe('Complex Form Integration', () => {
    it('should handle multi-section forms with various field types', async () => {
      const onSubmit = vi.fn();

      render(
        <DynamicFormRenderer
          configuration={complexFormConfig}
          onSubmit={onSubmit}
        />
      );

      // Check both sections are rendered
      expect(screen.getByText('Personal Information')).toBeInTheDocument();
      expect(screen.getByText('Travel Preferences')).toBeInTheDocument();

      // Fill out personal information
      await user.type(screen.getByLabelText(/first name/i), 'Jane');
      await user.type(screen.getByLabelText(/last name/i), 'Smith');
      await user.type(screen.getByLabelText(/phone number/i), '+1234567890');

      // Fill out travel preferences
      await user.type(screen.getByLabelText(/departure city/i), 'New York');
      await user.type(screen.getByLabelText(/destination city/i), 'Los Angeles');

      // Check flexible dates to show conditional field
      await user.click(screen.getByLabelText(/i have flexible dates/i));

      await waitFor(() => {
        expect(screen.getByLabelText(/date flexibility/i)).toBeInTheDocument();
      });

      // Select date flexibility
      await user.selectOptions(screen.getByLabelText(/date flexibility/i), '3');

      // Submit form
      await user.click(screen.getByRole('button', { name: /submit/i }));

      await waitFor(() => {
        expect(onSubmit).toHaveBeenCalledWith(
          expect.objectContaining({
            formId: 'complex_test_form',
            data: expect.objectContaining({
              first_name: 'Jane',
              last_name: 'Smith',
              phone: '+1234567890',
              departure_city: 'New York',
              destination_city: 'Los Angeles',
              flexible_dates: true,
              date_flexibility: '3'
            })
          })
        );
      });
    });
  });

  describe('Form Builder Integration', () => {
    it('should create and preview a form configuration', async () => {
      const onSave = vi.fn();

      render(
        <FormBuilder
          onSave={onSave}
          showPreview={true}
        />
      );

      // Should show form builder interface
      expect(screen.getByText(/form builder/i)).toBeInTheDocument();
      expect(screen.getByText(/field library/i)).toBeInTheDocument();

      // Should show preview panel
      expect(screen.getByText(/live preview/i)).toBeInTheDocument();
    });

    it('should handle form configuration validation', async () => {
      const mockValidate = vi.mocked(formConfigService.validateConfiguration);
      mockValidate.mockResolvedValue({
        success: true,
        isValid: true,
        validationResults: {
          isSecure: true,
          violations: [],
          recommendations: []
        }
      });

      render(
        <FormBuilder
          initialConfiguration={simpleFormConfig}
          showPreview={true}
        />
      );

      // Find and click validate button
      const validateButton = screen.getByRole('button', { name: /validate/i });
      await user.click(validateButton);

      await waitFor(() => {
        expect(mockValidate).toHaveBeenCalledWith(
          expect.objectContaining({
            id: 'simple_test_form',
            name: 'Simple Test Form'
          }),
          'comprehensive',
          true
        );
      });
    });
  });

  describe('Analytics Integration', () => {
    it('should log form interactions and submissions', async () => {
      const mockLogAnalytics = vi.mocked(formConfigService.logAnalytics);
      const onSubmit = vi.fn();

      render(
        <DynamicFormRenderer
          configuration={simpleFormConfig}
          onSubmit={onSubmit}
          enableAnalytics={true}
        />
      );

      // Fill and submit form
      await user.type(screen.getByLabelText(/full name/i), 'John Doe');
      await user.type(screen.getByLabelText(/email address/i), 'john@example.com');
      await user.click(screen.getByRole('button', { name: /submit/i }));

      await waitFor(() => {
        expect(mockLogAnalytics).toHaveBeenCalledWith(
          'simple_test_form',
          'form_submit',
          expect.objectContaining({
            formVersion: 1,
            fieldCount: expect.any(Number)
          })
        );
      });
    });
  });

  describe('Accessibility Integration', () => {
    it('should be accessible to screen readers', async () => {
      const { container } = render(
        <DynamicFormRenderer
          configuration={simpleFormConfig}
          onSubmit={vi.fn()}
        />
      );

      const results = await axe(container);
      expect(results).toHaveNoViolations();
    });

    it('should support keyboard navigation', async () => {
      render(
        <DynamicFormRenderer
          configuration={simpleFormConfig}
          onSubmit={vi.fn()}
        />
      );

      const nameInput = screen.getByLabelText(/full name/i);
      const emailInput = screen.getByLabelText(/email address/i);
      const ageInput = screen.getByLabelText(/age/i);
      const submitButton = screen.getByRole('button', { name: /submit/i });

      // Test tab navigation
      nameInput.focus();
      expect(document.activeElement).toBe(nameInput);

      fireEvent.keyDown(nameInput, { key: 'Tab' });
      await waitFor(() => {
        expect(document.activeElement).toBe(emailInput);
      });

      fireEvent.keyDown(emailInput, { key: 'Tab' });
      await waitFor(() => {
        expect(document.activeElement).toBe(ageInput);
      });

      fireEvent.keyDown(ageInput, { key: 'Tab' });
      await waitFor(() => {
        expect(document.activeElement).toBe(submitButton);
      });
    });

    it('should provide proper ARIA labels and descriptions', () => {
      render(
        <DynamicFormRenderer
          configuration={simpleFormConfig}
          onSubmit={vi.fn()}
        />
      );

      // Check for proper labeling
      const nameInput = screen.getByLabelText(/full name/i);
      expect(nameInput).toHaveAttribute('aria-required', 'true');

      const emailInput = screen.getByLabelText(/email address/i);
      expect(emailInput).toHaveAttribute('aria-required', 'true');

      // Check for form validation messages
      expect(screen.getByRole('form')).toBeInTheDocument();
    });
  });

  describe('Error Handling Integration', () => {
    it('should handle form submission errors gracefully', async () => {
      const onSubmit = vi.fn().mockRejectedValue(new Error('Submission failed'));
      const onError = vi.fn();

      render(
        <DynamicFormRenderer
          configuration={simpleFormConfig}
          onSubmit={onSubmit}
          onError={onError}
        />
      );

      // Fill out form
      await user.type(screen.getByLabelText(/full name/i), 'John Doe');
      await user.type(screen.getByLabelText(/email address/i), 'john@example.com');

      // Submit form
      await user.click(screen.getByRole('button', { name: /submit/i }));

      await waitFor(() => {
        expect(onError).toHaveBeenCalledWith(
          expect.objectContaining({
            message: 'Submission failed'
          })
        );
      });
    });

    it('should handle configuration loading errors', async () => {
      const mockGetConfig = vi.mocked(formConfigService.getConfiguration);
      mockGetConfig.mockResolvedValue({
        success: false,
        error: {
          code: 'CONFIG_NOT_FOUND',
          message: 'Configuration not found'
        }
      });

      render(
        <DynamicFormRenderer
          configId="non_existent_form"
          onSubmit={vi.fn()}
        />
      );

      await waitFor(() => {
        expect(screen.getByText(/failed to load form configuration/i)).toBeInTheDocument();
      });
    });
  });

  describe('Real-time Validation Integration', () => {
    it('should validate fields in real-time when enabled', async () => {
      render(
        <DynamicFormRenderer
          configuration={simpleFormConfig}
          onSubmit={vi.fn()}
          realTimeValidation={true}
        />
      );

      const nameInput = screen.getByLabelText(/full name/i);

      // Type invalid input (too short)
      await user.type(nameInput, 'A');
      
      await waitFor(() => {
        expect(screen.getByText(/name must be at least 2 characters/i)).toBeInTheDocument();
      });

      // Complete the input
      await user.type(nameInput, 'lice');

      await waitFor(() => {
        expect(screen.queryByText(/name must be at least 2 characters/i)).not.toBeInTheDocument();
      });
    });
  });

  describe('State Management Integration', () => {
    it('should integrate with form store for configuration management', async () => {
      const mockStore = useFormStore.getState();
      const mockLoadConfig = vi.fn();
      mockStore.loadConfiguration = mockLoadConfig;

      render(
        <DynamicFormRenderer
          configId="test_form"
          onSubmit={vi.fn()}
        />
      );

      // Should attempt to load configuration from store
      expect(mockLoadConfig).toHaveBeenCalledWith('test_form');
    });
  });
});

// Export test utilities
export const integrationTestUtils = {
  simpleFormConfig,
  conditionalFormConfig,
  complexFormConfig,
  
  // Helper to create test forms
  createTestForm: (config: DynamicFormConfig, props: any = {}) => {
    return render(
      <DynamicFormRenderer
        configuration={config}
        onSubmit={vi.fn()}
        {...props}
      />
    );
  },

  // Helper to fill out a form
  fillForm: async (user: any, data: Record<string, any>) => {
    for (const [fieldName, value] of Object.entries(data)) {
      const field = screen.getByLabelText(new RegExp(fieldName, 'i'));
      
      if (field.tagName === 'INPUT' && field.getAttribute('type') === 'checkbox') {
        if (value) {
          await user.click(field);
        }
      } else if (field.tagName === 'SELECT') {
        await user.selectOptions(field, value);
      } else {
        await user.type(field, value.toString());
      }
    }
  }
};
