import { ReactNode } from 'react';
import { useBusinessRules } from '../hooks/useBusinessRules';
import { useFeatureFlag } from '../lib/feature-flags/useFeatureFlag';

interface LegacyFormAdapterProps {
  children: ReactNode;
  fallbackComponent?: ReactNode;
}

export function LegacyFormAdapter({ children, fallbackComponent }: LegacyFormAdapterProps) {
  const { config, loading, error } = useBusinessRules();
  const { enabled: configDrivenFormsEnabled } = useFeatureFlag('ENABLE_CONFIG_DRIVEN_FORMS');

  // Show loading state
  if (loading) {
    return <div className="animate-pulse bg-gray-100 p-4 rounded">Loading configuration...</div>;
  }

  // Show error state and fallback
  if (error || !config) {
    console.warn('BusinessRules config unavailable, falling back to legacy forms:', error);
    return fallbackComponent || <div className="bg-yellow-50 border border-yellow-200 p-4 rounded">Form temporarily unavailable</div>;
  }

  // Emergency disable check
  if (config.emergencyDisable) {
    return (
      <div className="bg-red-50 border border-red-200 p-4 rounded">
        <h3 className="text-red-800 font-semibold">Service Temporarily Unavailable</h3>
        <p className="text-red-700">{config.emergencyMessage || 'Please try again later.'}</p>
      </div>
    );
  }

  // Feature flag check
  if (!configDrivenFormsEnabled) {
    return fallbackComponent || children;
  }

  return <>{children}</>;
}
