/**
 * DynamicFormRenderer Component Tests
 * 
 * Unit tests for the core dynamic form rendering component
 */

import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { vi, describe, it, expect, beforeEach } from 'vitest';
import { DynamicFormRenderer } from './DynamicFormRenderer';
import { createMockFormConfiguration } from '@/tests/setup-dynamic-forms';

// Mock the hooks
vi.mock('@/hooks/useFormConfiguration', () => ({
  useFormConfiguration: vi.fn(),
}));
vi.mock('@/hooks/useFormState', () => ({
  useFormState: vi.fn(),
}));
vi.mock('@/lib/form-validation', () => ({
  generateZodSchema: vi.fn(),
}));

const mockUseFormConfiguration = vi.hoisted(() => ({
  configuration: null,
  loading: false,
  error: null
}));

const mockUseFormState = vi.hoisted(() => ({
  formState: {
    values: {},
    errors: {},
    touched: {},
    isSubmitting: false,
    isValid: true
  },
  setValue: vi.fn(),
  setError: vi.fn(),
  clearError: vi.fn(),
  validateForm: vi.fn(() => true),
  resetForm: vi.fn(),
  isFieldVisible: vi.fn(() => true),
  isFieldEnabled: vi.fn(() => true)
}));

const mockGenerateZodSchema = vi.hoisted(() => vi.fn(() => ({
  parse: vi.fn(),
  safeParse: vi.fn(() => ({ success: true }))
})));

const mockUseForm = vi.hoisted(() => ({
  control: {},
  handleSubmit: vi.fn((fn) => fn),
  formState: {
    errors: {},
    isSubmitting: false,
    isValid: true
  },
  setValue: vi.fn(),
  clearErrors: vi.fn(),
  watch: vi.fn(() => vi.fn())
}));

vi.mock('react-hook-form', () => ({
  useForm: vi.fn(() => mockUseForm),
  FormProvider: ({ children }: any) => children
}));

describe('DynamicFormRenderer', () => {
  const mockConfiguration = createMockFormConfiguration({
    sections: [
      {
        id: 'section-1',
        title: 'Personal Information',
        description: 'Enter your personal details',
        fields: [
          {
            id: 'firstName',
            type: 'text',
            label: 'First Name',
            placeholder: 'Enter your first name',
            validation: { required: true }
          },
          {
            id: 'email',
            type: 'email',
            label: 'Email Address',
            placeholder: 'Enter your email',
            validation: { required: true, email: true }
          }
        ]
      }
    ]
  });

  beforeEach(async () => {
    vi.clearAllMocks();
    
    // Setup mocks
    const useFormConfiguration = vi.mocked((await import('@/hooks/useFormConfiguration')).useFormConfiguration);
    const useFormState = vi.mocked((await import('@/hooks/useFormState')).useFormState);
    const generateZodSchema = vi.mocked((await import('@/lib/form-validation')).generateZodSchema);
    
    useFormConfiguration.mockReturnValue(mockUseFormConfiguration);
    useFormState.mockReturnValue(mockUseFormState);
    generateZodSchema.mockReturnValue(mockGenerateZodSchema());
  });

  describe('Rendering', () => {
    it('should render loading state', () => {
      const { rerender } = render(
        <DynamicFormRenderer configId="test-config" />
      );

      // Mock loading state
      mockUseFormConfiguration.loading = true;
      rerender(<DynamicFormRenderer configId="test-config" />);

      expect(screen.getByText('Loading form configuration...')).toBeInTheDocument();
    });

    it('should render error state', () => {
      const { rerender } = render(
        <DynamicFormRenderer configId="test-config" />
      );

      // Mock error state
      mockUseFormConfiguration.error = 'Failed to load configuration';
      rerender(<DynamicFormRenderer configId="test-config" />);

      expect(screen.getByText('Failed to load configuration')).toBeInTheDocument();
    });

    it('should render form when configuration is provided', () => {
      render(
        <DynamicFormRenderer 
          configuration={mockConfiguration}
          onSubmit={vi.fn()}
        />
      );

      expect(screen.getByText('Personal Information')).toBeInTheDocument();
      expect(screen.getByText('Enter your personal details')).toBeInTheDocument();
      expect(screen.getByLabelText('First Name *')).toBeInTheDocument();
      expect(screen.getByLabelText('Email Address *')).toBeInTheDocument();
      expect(screen.getByRole('button', { name: 'Submit' })).toBeInTheDocument();
    });

    it('should render form with configuration from hook', () => {
      mockUseFormConfiguration.configuration = mockConfiguration;
      mockUseFormConfiguration.loading = false;
      mockUseFormConfiguration.error = null;

      render(
        <DynamicFormRenderer 
          configId="test-config"
          onSubmit={vi.fn()}
        />
      );

      expect(screen.getByText('Personal Information')).toBeInTheDocument();
    });
  });

  describe('Form Interaction', () => {
    it('should handle field changes', async () => {
      render(
        <DynamicFormRenderer 
          configuration={mockConfiguration}
          onSubmit={vi.fn()}
          onFieldChange={vi.fn()}
        />
      );

      const firstNameInput = screen.getByLabelText('First Name *');
      fireEvent.change(firstNameInput, { target: { value: 'John' } });

      await waitFor(() => {
        expect(mockUseFormState.setValue).toHaveBeenCalledWith('firstName', 'John');
      });
    });

    it('should handle form submission', async () => {
      const mockOnSubmit = vi.fn();
      
      render(
        <DynamicFormRenderer 
          configuration={mockConfiguration}
          onSubmit={mockOnSubmit}
        />
      );

      const submitButton = screen.getByRole('button', { name: 'Submit' });
      fireEvent.click(submitButton);

      await waitFor(() => {
        expect(mockUseForm.handleSubmit).toHaveBeenCalled();
      });
    });

    it('should show validation errors', () => {
      mockUseForm.formState.errors = {
        firstName: { message: 'First name is required' },
        email: { message: 'Invalid email format' }
      };

      render(
        <DynamicFormRenderer 
          configuration={mockConfiguration}
          onSubmit={vi.fn()}
          showValidationSummary={true}
        />
      );

      expect(screen.getByText('Please fix the following errors:')).toBeInTheDocument();
      expect(screen.getByText('First name is required')).toBeInTheDocument();
      expect(screen.getByText('Invalid email format')).toBeInTheDocument();
    });

    it('should handle validation errors callback', async () => {
      const mockOnValidationError = vi.fn();
      mockUseFormState.validateForm = vi.fn(() => false);
      mockUseForm.formState.errors = {
        firstName: { message: 'Required field' }
      };

      render(
        <DynamicFormRenderer 
          configuration={mockConfiguration}
          onSubmit={vi.fn()}
          onValidationError={mockOnValidationError}
        />
      );

      const submitButton = screen.getByRole('button', { name: 'Submit' });
      fireEvent.click(submitButton);

      await waitFor(() => {
        expect(mockOnValidationError).toHaveBeenCalledWith({
          firstName: 'Required field'
        });
      });
    });
  });

  describe('Conditional Logic', () => {
    it('should hide sections based on conditional logic', () => {
      const configWithConditional = createMockFormConfiguration({
        sections: [
          {
            id: 'section-1',
            title: 'Visible Section',
            fields: [
              {
                id: 'field1',
                type: 'text',
                label: 'Field 1'
              }
            ]
          },
          {
            id: 'section-2',
            title: 'Hidden Section',
            fields: [
              {
                id: 'field2',
                type: 'text',
                label: 'Field 2'
              }
            ],
            conditional: {
              showWhen: { field: 'field1', operator: 'equals', value: 'show' }
            }
          }
        ]
      });

      render(
        <DynamicFormRenderer 
          configuration={configWithConditional}
          onSubmit={vi.fn()}
        />
      );

      expect(screen.getByText('Visible Section')).toBeInTheDocument();
      // Hidden section should not be visible based on conditional logic
    });

    it('should handle field visibility', () => {
      mockUseFormState.isFieldVisible = vi.fn((field) => field.id !== 'hiddenField');

      const configWithHiddenField = createMockFormConfiguration({
        sections: [
          {
            id: 'section-1',
            title: 'Test Section',
            fields: [
              {
                id: 'visibleField',
                type: 'text',
                label: 'Visible Field'
              },
              {
                id: 'hiddenField',
                type: 'text',
                label: 'Hidden Field'
              }
            ]
          }
        ]
      });

      render(
        <DynamicFormRenderer 
          configuration={configWithHiddenField}
          onSubmit={vi.fn()}
        />
      );

      expect(screen.getByLabelText('Visible Field')).toBeInTheDocument();
      expect(screen.queryByLabelText('Hidden Field')).not.toBeInTheDocument();
    });
  });

  describe('Props', () => {
    it('should be disabled when disabled prop is true', () => {
      render(
        <DynamicFormRenderer 
          configuration={mockConfiguration}
          onSubmit={vi.fn()}
          disabled={true}
        />
      );

      const submitButton = screen.getByRole('button', { name: 'Submit' });
      expect(submitButton).toBeDisabled();
    });

    it('should hide validation summary when showValidationSummary is false', () => {
      mockUseForm.formState.errors = {
        firstName: { message: 'Required field' }
      };

      render(
        <DynamicFormRenderer 
          configuration={mockConfiguration}
          onSubmit={vi.fn()}
          showValidationSummary={false}
        />
      );

      expect(screen.queryByText('Please fix the following errors:')).not.toBeInTheDocument();
    });

    it('should apply custom className', () => {
      const { container } = render(
        <DynamicFormRenderer 
          configuration={mockConfiguration}
          onSubmit={vi.fn()}
          className="custom-form-class"
        />
      );

      expect(container.firstChild).toHaveClass('custom-form-class');
    });
  });

  describe('Accessibility', () => {
    it('should have proper ARIA labels', () => {
      render(
        <DynamicFormRenderer 
          configuration={mockConfiguration}
          onSubmit={vi.fn()}
        />
      );

      const form = screen.getByRole('form');
      expect(form).toBeInTheDocument();

      const submitButton = screen.getByRole('button', { name: 'Submit' });
      expect(submitButton).toHaveAttribute('type', 'submit');
    });

    it('should associate labels with inputs', () => {
      render(
        <DynamicFormRenderer 
          configuration={mockConfiguration}
          onSubmit={vi.fn()}
        />
      );

      const firstNameInput = screen.getByLabelText('First Name *');
      const emailInput = screen.getByLabelText('Email Address *');

      expect(firstNameInput).toBeInTheDocument();
      expect(emailInput).toBeInTheDocument();
    });
  });
});
