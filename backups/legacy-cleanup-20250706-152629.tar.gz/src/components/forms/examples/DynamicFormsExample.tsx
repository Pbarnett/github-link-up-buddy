/**
 * Dynamic Forms Example Component
 * 
 * Demonstrates how to use the dynamic forms system with real examples
 */

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Label } from '@/components/ui/label';
import { 
  Lightbulb, 
  Plane, 
  CreditCard, 
  Users, 
  CheckCircle, 
  Clock,
  Zap,
  Target
} from 'lucide-react';

import { DynamicFormRenderer } from '../DynamicFormRenderer';
import { FormBuilder } from '../FormBuilder';
import { FormConfigDirectService } from '@/services/form-config-direct.service';
import type { FormConfiguration, FormSubmissionData } from '@/types/dynamic-forms';

// Example form configurations
const EXAMPLE_FORMS: Record<string, FormConfiguration> = {
  'flight-search': {
    id: 'flight-search-v1',
    name: 'Flight Search Form',
    title: 'Find Your Perfect Flight',
    description: 'Search and book flights with our smart search engine',
    version: 1,
    sections: [
      {
        id: 'travel-details',
        title: 'Travel Details',
        description: 'Tell us where and when you want to travel',
        fields: [
          {
            id: 'origin',
            type: 'airport-autocomplete',
            label: 'From',
            placeholder: 'Enter departure airport',
            validation: { required: true },
            description: 'Select your departure airport'
          },
          {
            id: 'destination',
            type: 'airport-autocomplete',
            label: 'To',
            placeholder: 'Enter destination airport',
            validation: { required: true },
            description: 'Select your destination airport'
          },
          {
            id: 'trip-type',
            type: 'select',
            label: 'Trip Type',
            options: [
              { label: 'Round Trip', value: 'round-trip' },
              { label: 'One Way', value: 'one-way' },
              { label: 'Multi-City', value: 'multi-city' }
            ],
            defaultValue: 'round-trip',
            validation: { required: true }
          },
          {
            id: 'departure-date',
            type: 'date',
            label: 'Departure Date',
            validation: { required: true }
          },
          {
            id: 'return-date',
            type: 'date',
            label: 'Return Date',
            conditional: {
              showWhen: { field: 'trip-type', operator: 'equals', value: 'round-trip' }
            },
            validation: { required: false }
          }
        ]
      },
      {
        id: 'passenger-details',
        title: 'Passengers',
        fields: [
          {
            id: 'adults',
            type: 'number',
            label: 'Adults',
            defaultValue: 1,
            validation: { required: true, min: 1, max: 9 }
          },
          {
            id: 'children',
            type: 'number',
            label: 'Children (2-11)',
            defaultValue: 0,
            validation: { required: false, min: 0, max: 8 }
          },
          {
            id: 'infants',
            type: 'number',
            label: 'Infants (under 2)',
            defaultValue: 0,
            validation: { required: false, min: 0, max: 4 }
          }
        ]
      },
      {
        id: 'preferences',
        title: 'Travel Preferences',
        fields: [
          {
            id: 'cabin-class',
            type: 'select',
            label: 'Cabin Class',
            options: [
              { label: 'Economy', value: 'economy' },
              { label: 'Premium Economy', value: 'premium-economy' },
              { label: 'Business', value: 'business' },
              { label: 'First', value: 'first' }
            ],
            defaultValue: 'economy'
          },
          {
            id: 'flexible-dates',
            type: 'checkbox',
            label: 'My dates are flexible',
            description: 'Show flights ±3 days from selected dates'
          },
          {
            id: 'direct-flights-only',
            type: 'checkbox',
            label: 'Direct flights only',
            description: 'Show only non-stop flights'
          }
        ]
      }
    ],
    metadata: {
      created: new Date().toISOString(),
      createdBy: 'system',
      lastModified: new Date().toISOString(),
      tags: ['flight', 'booking', 'travel']
    }
  },

  'payment-setup': {
    id: 'payment-setup-v1',
    name: 'Payment Method Setup',
    title: 'Add Payment Method',
    description: 'Securely add a payment method to your account',
    version: 1,
    sections: [
      {
        id: 'payment-details',
        title: 'Payment Information',
        fields: [
          {
            id: 'cardholder-name',
            type: 'text',
            label: 'Cardholder Name',
            placeholder: 'Name as it appears on card',
            validation: { required: true, minLength: 2 }
          },
          {
            id: 'card-number',
            type: 'text',
            label: 'Card Number',
            placeholder: '1234 5678 9012 3456',
            validation: { 
              required: true,
              pattern: '^[0-9]{13,19}$',
              message: 'Please enter a valid card number'
            }
          },
          {
            id: 'expiry-date',
            type: 'text',
            label: 'Expiry Date',
            placeholder: 'MM/YY',
            validation: { 
              required: true,
              pattern: '^(0[1-9]|1[0-2])/([0-9]{2})$',
              message: 'Please enter expiry date in MM/YY format'
            }
          },
          {
            id: 'cvv',
            type: 'password',
            label: 'CVV',
            placeholder: '123',
            validation: { 
              required: true,
              pattern: '^[0-9]{3,4}$',
              message: 'Please enter a valid CVV'
            }
          }
        ]
      },
      {
        id: 'billing-address',
        title: 'Billing Address',
        fields: [
          {
            id: 'country',
            type: 'country-select',
            label: 'Country',
            validation: { required: true }
          },
          {
            id: 'address',
            type: 'address-group',
            label: 'Address',
            validation: { required: true }
          },
          {
            id: 'save-for-future',
            type: 'checkbox',
            label: 'Save this payment method for future purchases',
            defaultValue: true
          }
        ]
      }
    ],
    metadata: {
      created: new Date().toISOString(),
      createdBy: 'system',
      lastModified: new Date().toISOString(),
      tags: ['payment', 'billing', 'security'],
      security: {
        pciCompliant: true,
        encryptSensitiveFields: true
      }
    }
  },

  'contact-form': {
    id: 'contact-form-v1',
    name: 'Contact Us Form',
    title: 'Get in Touch',
    description: 'We\'d love to hear from you. Send us a message and we\'ll respond as soon as possible.',
    version: 1,
    sections: [
      {
        id: 'contact-info',
        title: 'Your Information',
        fields: [
          {
            id: 'first-name',
            type: 'text',
            label: 'First Name',
            validation: { required: true, minLength: 2 }
          },
          {
            id: 'last-name',
            type: 'text',
            label: 'Last Name',
            validation: { required: true, minLength: 2 }
          },
          {
            id: 'email',
            type: 'email',
            label: 'Email Address',
            validation: { required: true }
          },
          {
            id: 'phone',
            type: 'phone',
            label: 'Phone Number',
            description: 'Optional - for urgent inquiries'
          }
        ]
      },
      {
        id: 'inquiry-details',
        title: 'Your Inquiry',
        fields: [
          {
            id: 'subject',
            type: 'select',
            label: 'Subject',
            options: [
              { label: 'General Inquiry', value: 'general' },
              { label: 'Booking Support', value: 'booking' },
              { label: 'Technical Issue', value: 'technical' },
              { label: 'Billing Question', value: 'billing' },
              { label: 'Partnership', value: 'partnership' }
            ],
            validation: { required: true }
          },
          {
            id: 'priority',
            type: 'select',
            label: 'Priority',
            options: [
              { label: 'Low', value: 'low' },
              { label: 'Medium', value: 'medium' },
              { label: 'High', value: 'high' },
              { label: 'Urgent', value: 'urgent' }
            ],
            defaultValue: 'medium',
            conditional: {
              showWhen: { field: 'subject', operator: 'oneOf', value: ['technical', 'billing'] }
            }
          },
          {
            id: 'message',
            type: 'textarea',
            label: 'Message',
            placeholder: 'Please describe your inquiry in detail...',
            validation: { required: true, minLength: 10, maxLength: 1000 }
          },
          {
            id: 'newsletter-signup',
            type: 'checkbox',
            label: 'Subscribe to our newsletter for updates and travel tips'
          }
        ]
      }
    ],
    metadata: {
      created: new Date().toISOString(),
      createdBy: 'system',
      lastModified: new Date().toISOString(),
      tags: ['contact', 'support', 'inquiry']
    }
  }
};

export const DynamicFormsExample: React.FC = () => {
  const [activeExample, setActiveExample] = useState<string>('flight-search-v1');
  const [submissionResults, setSubmissionResults] = useState<any>(null);
  const [showBuilder, setShowBuilder] = useState(false);
  const [forms, setForms] = useState<Record<string, FormConfiguration>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load forms from database on component mount
  React.useEffect(() => {
    const loadForms = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Load all deployed forms from database
        const [flightSearch, paymentSetup, customerSurvey] = await Promise.all([
          FormConfigDirectService.getConfigurationByName('flight-search-v1'),
          FormConfigDirectService.getConfigurationByName('payment-setup-v1'),
          FormConfigDirectService.getConfigurationByName('customer-survey-v1')
        ]);
        
        const loadedForms: Record<string, FormConfiguration> = {};
        
        if (flightSearch) loadedForms['flight-search-v1'] = flightSearch;
        if (paymentSetup) loadedForms['payment-setup-v1'] = paymentSetup;
        if (customerSurvey) loadedForms['customer-survey-v1'] = customerSurvey;
        
        setForms(loadedForms);
        
        // Set first available form as active
        const firstFormKey = Object.keys(loadedForms)[0];
        if (firstFormKey) {
          setActiveExample(firstFormKey);
        }
      } catch (err) {
        console.error('Failed to load forms:', err);
        setError('Failed to load form configurations from database');
      } finally {
        setLoading(false);
      }
    };
    
    loadForms();
  }, []);

  const handleFormSubmission = async (data: FormSubmissionData) => {
    console.log('Form submitted:', data);
    
    // Simulate API submission
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setSubmissionResults({
      success: true,
      formName: data.formName,
      submittedAt: data.metadata.submittedAt,
      dataKeys: Object.keys(data.data)
    });
  };

  const currentForm = forms[activeExample];

  if (showBuilder) {
    return (
      <div className="container mx-auto p-6">
        <div className="mb-4">
          <Button 
            variant="outline" 
            onClick={() => setShowBuilder(false)}
            className="mb-4"
          >
            ← Back to Examples
          </Button>
        </div>
        <FormBuilder
          onSave={(config) => {
            console.log('Form saved:', config);
            setShowBuilder(false);
          }}
          onDeploy={(configId) => {
            console.log('Form deployed:', configId);
          }}
        />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">Dynamic Forms System</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Experience the power of configuration-driven forms. Build, deploy, and update forms 
          without code changes - from simple contact forms to complex multi-step wizards.
        </p>
        
        {/* Key Benefits */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-8">
          <Card>
            <CardContent className="p-4 text-center">
              <Zap className="h-8 w-8 mx-auto mb-2 text-blue-500" />
              <h3 className="font-semibold">15-Minute Deployment</h3>
              <p className="text-sm text-muted-foreground">Down from 2-4 hours</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Target className="h-8 w-8 mx-auto mb-2 text-green-500" />
              <h3 className="font-semibold">A/B Testing Built-in</h3>
              <p className="text-sm text-muted-foreground">Test variants instantly</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Clock className="h-8 w-8 mx-auto mb-2 text-purple-500" />
              <h3 className="font-semibold">Real-time Updates</h3>
              <p className="text-sm text-muted-foreground">No code deployments</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <CheckCircle className="h-8 w-8 mx-auto mb-2 text-orange-500" />
              <h3 className="font-semibold">Instant Rollback</h3>
              <p className="text-sm text-muted-foreground">Zero-risk deployments</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Examples Section */}
      <Tabs value={activeExample} onValueChange={setActiveExample}>
        <div className="flex justify-between items-center">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="flight-search-v1" className="flex items-center gap-2">
              <Plane className="h-4 w-4" />
              Flight Search
            </TabsTrigger>
            <TabsTrigger value="payment-setup-v1" className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              Payment
            </TabsTrigger>
            <TabsTrigger value="customer-survey-v1" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Survey
            </TabsTrigger>
          </TabsList>

          <Button 
            onClick={() => setShowBuilder(true)}
            className="flex items-center gap-2"
          >
            <Lightbulb className="h-4 w-4" />
            Open Form Builder
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Form Preview */}
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      {activeExample === 'flight-search-v1' && <Plane className="h-5 w-5" />}
                      {activeExample === 'payment-setup-v1' && <CreditCard className="h-5 w-5" />}
                      {activeExample === 'customer-survey-v1' && <Users className="h-5 w-5" />}
                      {loading && 'Loading...'}
                      {!loading && currentForm && currentForm.title}
                      {!loading && !currentForm && error && 'Form Configuration Error'}
                    </CardTitle>
                    <CardDescription>
                      {loading && 'Loading form configuration...'}
                      {!loading && currentForm && currentForm.description}
                      {!loading && !currentForm && error && error}
                    </CardDescription>
                  </div>
                  {!loading && currentForm && <Badge variant="secondary">v{currentForm.version}</Badge>}
                </div>
              </CardHeader>
              <CardContent>
                {loading && (
                  <div className="flex items-center justify-center py-8">
                    <div className="text-center space-y-2">
                      <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full mx-auto"></div>
                      <p className="text-sm text-muted-foreground">Loading form configuration...</p>
                    </div>
                  </div>
                )}
                {!loading && error && (
                  <Alert variant="destructive">
                    <AlertDescription>
                      {error}
                    </AlertDescription>
                  </Alert>
                )}
                {!loading && !error && currentForm && (
                  <DynamicFormRenderer
                    configuration={currentForm}
                    onSubmit={handleFormSubmission}
                    showValidationSummary={true}
                  />
                )}
              </CardContent>
            </Card>

            {/* Submission Results */}
            {submissionResults && (
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  <div className="space-y-2">
                    <p className="font-medium">Form submitted successfully!</p>
                    <div className="text-sm space-y-1">
                      <p><strong>Form:</strong> {submissionResults.formName}</p>
                      <p><strong>Submitted:</strong> {new Date(submissionResults.submittedAt).toLocaleString()}</p>
                      <p><strong>Fields:</strong> {submissionResults.dataKeys.join(', ')}</p>
                    </div>
                  </div>
                </AlertDescription>
              </Alert>
            )}
          </div>

          {/* Configuration Preview */}
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Form Configuration</CardTitle>
                <CardDescription>
                  This form is generated from the JSON configuration below
                </CardDescription>
              </CardHeader>
              <CardContent>
                {loading && (
                  <div className="flex items-center justify-center py-8">
                    <div className="text-center space-y-2">
                      <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full mx-auto"></div>
                      <p className="text-sm text-muted-foreground">Loading configuration...</p>
                    </div>
                  </div>
                )}
                {!loading && error && (
                  <Alert variant="destructive">
                    <AlertDescription>
                      Unable to load form configuration
                    </AlertDescription>
                  </Alert>
                )}
                {!loading && !error && currentForm && (
                  <div className="space-y-4">
                    {/* Form Metadata */}
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium">Sections:</span> {currentForm.sections.length}
                      </div>
                      <div>
                        <span className="font-medium">Fields:</span>{' '}
                        {currentForm.sections.reduce((count, section) => count + section.fields.length, 0)}
                      </div>
                      <div>
                        <span className="font-medium">Version:</span> {currentForm.version}
                      </div>
                      <div>
                        <span className="font-medium">Created:</span>{' '}
                        {currentForm.metadata?.created ? new Date(currentForm.metadata.created).toLocaleDateString() : 'Unknown'}
                      </div>
                    </div>

                    {/* Configuration JSON */}
                    <div>
                      <Label className="text-sm font-medium">JSON Configuration</Label>
                      <div className="mt-2 max-h-96 overflow-auto">
                        <pre className="bg-muted p-4 rounded-md text-xs overflow-x-auto">
                          {JSON.stringify(currentForm, null, 2)}
                        </pre>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </Tabs>

      {/* Features Showcase */}
      <Card>
        <CardHeader>
          <CardTitle>Dynamic Features Demonstrated</CardTitle>
          <CardDescription>
            See how these forms showcase the power of the dynamic forms system
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <h4 className="font-semibold">Conditional Logic</h4>
              <p className="text-sm text-muted-foreground">
                Return date field appears only for round-trip flights. Priority field shows for technical/billing inquiries.
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Smart Validation</h4>
              <p className="text-sm text-muted-foreground">
                Real-time validation with custom rules, field dependencies, and helpful error messages.
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Specialized Fields</h4>
              <p className="text-sm text-muted-foreground">
                Airport autocomplete, phone input, country selection, and address groups with API integration.
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Form Analytics</h4>
              <p className="text-sm text-muted-foreground">
                Track field interactions, completion rates, and user behavior patterns automatically.
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Security Features</h4>
              <p className="text-sm text-muted-foreground">
                PCI compliance for payment forms, field-level encryption, and secure data handling.
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Instant Updates</h4>
              <p className="text-sm text-muted-foreground">
                Change field labels, add options, or modify validation rules without code deployment.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Next Steps */}
      <Card>
        <CardHeader>
          <CardTitle>Ready to Get Started?</CardTitle>
          <CardDescription>
            Transform your form development workflow today
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <Button onClick={() => setShowBuilder(true)}>
              <Lightbulb className="h-4 w-4 mr-2" />
              Try the Form Builder
            </Button>
            <Button variant="outline">
              View Documentation
            </Button>
            <Button variant="outline">
              See Implementation Guide
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DynamicFormsExample;
