/**
 * Dynamic Forms Demo Page
 * 
 * Showcases the completed dynamic forms system with live examples
 */

import { DynamicFormsExample } from '@/components/forms/examples/DynamicFormsExample';

export default function DynamicFormsPage() {
  return <DynamicFormsExample />;
}

export const metadata = {
  title: 'Dynamic Forms System - Parker Flight',
  description: 'Experience the power of configuration-driven forms. Build, deploy, and update forms without code changes.',
};
