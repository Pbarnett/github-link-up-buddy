/**
 * AWS Services Configuration
 * Enhanced integration with AWS optimization patterns from AWS_Optimization_Answers.md
 */

import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import {
  DynamoDBDocumentClient,
  QueryCommand,
  PutCommand,
  UpdateCommand,
} from '@aws-sdk/lib-dynamodb';

import {
  S3Client,
  GetObjectCommand,
  PutObjectCommand,
} from '@aws-sdk/client-s3';
import {
  SecretsManagerClient,
  GetSecretValueCommand,
} from '@aws-sdk/client-secrets-manager';
import {
  KMSClient,
  EncryptCommand,
  DecryptCommand,
  DescribeKeyCommand,
} from '@aws-sdk/client-kms';

import {
  CloudWatchClient,
  PutMetricDataCommand,
} from '@aws-sdk/client-cloudwatch';

// Environment configuration
const AWS_REGION = process.env.VITE_AWS_REGION || 'us-east-1';
const IS_PRODUCTION = process.env.NODE_ENV === 'production';
const ENABLE_XRAY = process.env.VITE_ENABLE_XRAY === 'true';
const ENABLE_METRICS = process.env.VITE_ENABLE_METRICS === 'true';

// AWS SDK Configuration with optimization
const awsConfig = {
  region: AWS_REGION,
  maxAttempts: 3,
  retryMode: 'adaptive' as const,
  requestHandler: {
    requestTimeout: 10000, // 10 seconds
    connectionTimeout: 5000, // 5 seconds
  },
};

// Initialize AWS clients with X-Ray tracing
let AWSXRay: any;
let captureAWS: any;

if (ENABLE_XRAY && typeof window === 'undefined') {
  try {
    AWSXRay = require('aws-xray-sdk-core');
    captureAWS = AWSXRay.captureAWS;
  } catch (error) {
    console.warn('X-Ray SDK not available, disabling tracing:', error);
  }
}

// Create AWS clients
const createDynamoDBClient = () => {
  const client = new DynamoDBClient(awsConfig);
  return captureAWS
    ? DynamoDBDocumentClient.from(captureAWS(client))
    : DynamoDBDocumentClient.from(client);
};

const createS3Client = () => {
  const client = new S3Client(awsConfig);
  return captureAWS ? captureAWS(client) : client;
};

const createSecretsManagerClient = () => {
  const client = new SecretsManagerClient(awsConfig);
  return captureAWS ? captureAWS(client) : client;
};

const createCloudWatchClient = () => {
  const client = new CloudWatchClient(awsConfig);
  return captureAWS ? captureAWS(client) : client;
};

const createKMSClient = () => {
  const client = new KMSClient(awsConfig);
  return captureAWS ? captureAWS(client) : client;
};

// Singleton instances
let dynamoDbClient: DynamoDBDocumentClient | null = null;
let s3Client: S3Client | null = null;
let secretsManagerClient: SecretsManagerClient | null = null;
let cloudWatchClient: CloudWatchClient | null = null;
let kmsClient: KMSClient | null = null;

// Lazy initialization of clients
export const getDynamoDBClient = (): DynamoDBDocumentClient => {
  if (!dynamoDbClient) {
    dynamoDbClient = createDynamoDBClient();
  }
  return dynamoDbClient;
};

export const getS3Client = (): S3Client => {
  if (!s3Client) {
    s3Client = createS3Client();
  }
  return s3Client;
};

export const getSecretsManagerClient = (): SecretsManagerClient => {
  if (!secretsManagerClient) {
    secretsManagerClient = createSecretsManagerClient();
  }
  return secretsManagerClient;
};

export const getCloudWatchClient = (): CloudWatchClient => {
  if (!cloudWatchClient) {
    cloudWatchClient = createCloudWatchClient();
  }
  return cloudWatchClient;
};

export const getKMSClient = (): KMSClient => {
  if (!kmsClient) {
    kmsClient = createKMSClient();
  }
  return kmsClient;
};

// KMS configuration with alias-based key access for rotation support
export const kmsConfig = {
  keyAlias: process.env.KMS_KEY_ALIAS || 'alias/github-link-buddy-encryption-key',
  region: AWS_REGION,
  rotationConfig: {
    enabled: true,
    rotationPeriodInDays: 365, // Annual rotation
    autoUpdateAlias: true
  }
};

// Application configuration from environment
export const appConfig = {
  aws: {
    region: AWS_REGION,
    dynamoDbTable:
      process.env.DYNAMODB_TABLE || 'github-link-buddy-links-production',
    s3Bucket: process.env.S3_BUCKET || 'github-link-buddy-primary-bucket',
    kmsKeyAlias: kmsConfig.keyAlias, // Use alias instead of direct key ID
    databaseSecretArn: process.env.DATABASE_SECRET_ARN,
    apiKeysSecretArn: process.env.API_KEYS_SECRET_ARN,
  },
  features: {
    enableXRay: ENABLE_XRAY,
    enableMetrics: ENABLE_METRICS,
    enableCaching: IS_PRODUCTION,
    enableEncryption: true,
  },
  performance: {
    cacheTimeout: 300, // 5 minutes
    queryTimeout: 10000, // 10 seconds
    batchSize: 25, // DynamoDB batch operations
    retryAttempts: 3,
  },
};

// Enhanced DynamoDB operations with metrics and error handling
export class DynamoDBService {
  private client: DynamoDBDocumentClient;
  private tableName: string;

  constructor(tableName: string = appConfig.aws.dynamoDbTable) {
    this.client = getDynamoDBClient();
    this.tableName = tableName;
  }

  async getItem(id: string, userId?: string): Promise<any> {
    const startTime = Date.now();

    try {
      const command = new QueryCommand({
        TableName: this.tableName,
        KeyConditionExpression: 'id = :id',
        ExpressionAttributeValues: {
          ':id': id,
        },
        Limit: 1,
      });

      const result = await this.client.send(command);

      // Record custom metrics
      await this.recordMetric(
        'DynamoDB.GetItem.Duration',
        Date.now() - startTime
      );
      await this.recordMetric('DynamoDB.GetItem.Success', 1);

      return result.Items?.[0] || null;
    } catch (error) {
      await this.recordMetric('DynamoDB.GetItem.Error', 1);
      console.error('DynamoDB getItem error:', error);
      throw error;
    }
  }

  async putItem(item: any): Promise<void> {
    const startTime = Date.now();

    try {
      const command = new PutCommand({
        TableName: this.tableName,
        Item: {
          ...item,
          createdAt: item.createdAt || new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      });

      await this.client.send(command);

      await this.recordMetric(
        'DynamoDB.PutItem.Duration',
        Date.now() - startTime
      );
      await this.recordMetric('DynamoDB.PutItem.Success', 1);
    } catch (error) {
      await this.recordMetric('DynamoDB.PutItem.Error', 1);
      console.error('DynamoDB putItem error:', error);
      throw error;
    }
  }

  async queryByUser(
    userId: string, 
    limit: number = 50, 
    lastEvaluatedKey?: any
  ): Promise<{items: any[], lastKey?: any}> {
    const startTime = Date.now();

    try {
      const command = new QueryCommand({
        TableName: this.tableName,
        IndexName: 'UserIndex',
        KeyConditionExpression: 'userId = :userId',
        ExpressionAttributeValues: {
          ':userId': userId,
        },
        Limit: limit,
        ExclusiveStartKey: lastEvaluatedKey,
        ScanIndexForward: false, // Sort by creation date descending
      });

      const result = await this.client.send(command);

      await this.recordMetric(
        'DynamoDB.QueryByUser.Duration',
        Date.now() - startTime
      );
      await this.recordMetric('DynamoDB.QueryByUser.Success', 1);
      await this.recordMetric(
        'DynamoDB.QueryByUser.ItemCount',
        result.Items?.length || 0
      );
      
      // Track pagination usage for monitoring
      if (lastEvaluatedKey) {
        await this.recordMetric('DynamoDB.QueryByUser.PaginatedRequest', 1);
      }
      if (result.LastEvaluatedKey) {
        await this.recordMetric('DynamoDB.QueryByUser.HasMoreResults', 1);
      }

      return {
        items: result.Items || [],
        lastKey: result.LastEvaluatedKey
      };
    } catch (error) {
      await this.recordMetric('DynamoDB.QueryByUser.Error', 1);
      console.error('DynamoDB queryByUser error:', error);
      throw new Error(`Failed to query user data: ${error.message}`);
    }
  }

  // Backward compatibility helper - returns only items (for existing code)
  async queryByUserLegacy(userId: string, limit: number = 50): Promise<any[]> {
    const result = await this.queryByUser(userId, limit);
    return result.items;
  }

  // Advanced paginated query with all items (use with caution for large datasets)
  async queryByUserAll(userId: string, batchSize: number = 50): Promise<any[]> {
    let allItems: any[] = [];
    let lastKey: any = undefined;
    let requestCount = 0;
    const maxRequests = 20; // Safety limit to prevent runaway queries

    do {
      const result = await this.queryByUser(userId, batchSize, lastKey);
      allItems.push(...result.items);
      lastKey = result.lastKey;
      requestCount++;
      
      // Safety check to prevent excessive API calls
      if (requestCount >= maxRequests) {
        console.warn(`Query for user ${userId} exceeded ${maxRequests} requests, stopping pagination`);
        await this.recordMetric('DynamoDB.QueryByUser.MaxRequestsExceeded', 1);
        break;
      }
    } while (lastKey);

    await this.recordMetric('DynamoDB.QueryByUser.TotalRequests', requestCount);
    await this.recordMetric('DynamoDB.QueryByUser.TotalItems', allItems.length);

    return allItems;
  }

  private async recordMetric(metricName: string, value: number): Promise<void> {
    if (!ENABLE_METRICS) return;

    try {
      const cloudWatchClient = getCloudWatchClient();
      await cloudWatchClient.send(
        new PutMetricDataCommand({
          Namespace: 'GitHubLinkBuddy/Application',
          MetricData: [
            {
              MetricName: metricName,
              Value: value,
              Unit: metricName.includes('Duration') ? 'Milliseconds' : 'Count',
              Dimensions: [
                {
                  Name: 'Environment',
                  Value: IS_PRODUCTION ? 'production' : 'development',
                },
                { Name: 'Service', Value: 'DynamoDB' },
              ],
              Timestamp: new Date(),
            },
          ],
        })
      );
    } catch (error) {
      console.warn('Failed to record CloudWatch metric:', error);
    }
  }
}

// S3 Service for file operations
export class S3Service {
  private client: S3Client;
  private bucketName: string;

  constructor(bucketName: string = appConfig.aws.s3Bucket) {
    this.client = getS3Client();
    this.bucketName = bucketName;
  }

  async uploadFile(
    key: string,
    body: Buffer | Uint8Array | string
  ): Promise<string> {
    const startTime = Date.now();

    try {
      const command = new PutObjectCommand({
        Bucket: this.bucketName,
        Key: key,
        Body: body,
        ServerSideEncryption: 'aws:kms',
        SSEKMSKeyId: appConfig.aws.kmsKeyAlias, // Use alias for rotation support
        Metadata: {
          uploadedAt: new Date().toISOString(),
          service: 'github-link-buddy',
        },
      });

      await this.client.send(command);

      await this.recordMetric('S3.Upload.Duration', Date.now() - startTime);
      await this.recordMetric('S3.Upload.Success', 1);

      return `https://${this.bucketName}.s3.${AWS_REGION}.amazonaws.com/${key}`;
    } catch (error) {
      await this.recordMetric('S3.Upload.Error', 1);
      console.error('S3 upload error:', error);
      throw error;
    }
  }

  async downloadFile(key: string): Promise<string> {
    const startTime = Date.now();

    try {
      const command = new GetObjectCommand({
        Bucket: this.bucketName,
        Key: key,
      });

      const response = await this.client.send(command);
      const content = (await response.Body?.transformToString()) || '';

      await this.recordMetric('S3.Download.Duration', Date.now() - startTime);
      await this.recordMetric('S3.Download.Success', 1);

      return content;
    } catch (error) {
      await this.recordMetric('S3.Download.Error', 1);
      console.error('S3 download error:', error);
      throw error;
    }
  }

  private async recordMetric(metricName: string, value: number): Promise<void> {
    if (!ENABLE_METRICS) return;

    try {
      const cloudWatchClient = getCloudWatchClient();
      await cloudWatchClient.send(
        new PutMetricDataCommand({
          Namespace: 'GitHubLinkBuddy/Application',
          MetricData: [
            {
              MetricName: metricName,
              Value: value,
              Unit: metricName.includes('Duration') ? 'Milliseconds' : 'Count',
              Dimensions: [
                {
                  Name: 'Environment',
                  Value: IS_PRODUCTION ? 'production' : 'development',
                },
                { Name: 'Service', Value: 'S3' },
              ],
              Timestamp: new Date(),
            },
          ],
        })
      );
    } catch (error) {
      console.warn('Failed to record CloudWatch metric:', error);
    }
  }
}

// Secrets Manager Service for secure configuration
export class SecretsManagerService {
  private client: SecretsManagerClient;
  private cache: Map<string, { value: any; expiry: number }> = new Map();

  constructor() {
    this.client = getSecretsManagerClient();
  }

  async getSecret(secretArn: string, useCache: boolean = true): Promise<any> {
    // Check cache first
    if (useCache) {
      const cached = this.cache.get(secretArn);
      if (cached && Date.now() < cached.expiry) {
        return cached.value;
      }
    }

    const startTime = Date.now();

    try {
      const command = new GetSecretValueCommand({
        SecretId: secretArn,
      });

      const response = await this.client.send(command);
      const secretValue = response.SecretString
        ? JSON.parse(response.SecretString)
        : null;

      // Cache the result for 5 minutes
      if (useCache && secretValue) {
        this.cache.set(secretArn, {
          value: secretValue,
          expiry: Date.now() + 5 * 60 * 1000, // 5 minutes
        });
      }

      await this.recordMetric(
        'SecretsManager.GetSecret.Duration',
        Date.now() - startTime
      );
      await this.recordMetric('SecretsManager.GetSecret.Success', 1);

      return secretValue;
    } catch (error) {
      await this.recordMetric('SecretsManager.GetSecret.Error', 1);
      console.error('Secrets Manager error:', error);
      throw error;
    }
  }

  async getDatabaseCredentials(): Promise<any> {
    if (!appConfig.aws.databaseSecretArn) {
      throw new Error('Database secret ARN not configured');
    }
    return this.getSecret(appConfig.aws.databaseSecretArn);
  }

  async getAPIKeys(): Promise<any> {
    if (!appConfig.aws.apiKeysSecretArn) {
      throw new Error('API keys secret ARN not configured');
    }
    return this.getSecret(appConfig.aws.apiKeysSecretArn);
  }

  private async recordMetric(metricName: string, value: number): Promise<void> {
    if (!ENABLE_METRICS) return;

    try {
      const cloudWatchClient = getCloudWatchClient();
      await cloudWatchClient.send(
        new PutMetricDataCommand({
          Namespace: 'GitHubLinkBuddy/Application',
          MetricData: [
            {
              MetricName: metricName,
              Value: value,
              Unit: metricName.includes('Duration') ? 'Milliseconds' : 'Count',
              Dimensions: [
                {
                  Name: 'Environment',
                  Value: IS_PRODUCTION ? 'production' : 'development',
                },
                { Name: 'Service', Value: 'SecretsManager' },
              ],
              Timestamp: new Date(),
            },
          ],
        })
      );
    } catch (error) {
      console.warn('Failed to record CloudWatch metric:', error);
    }
  }
}

// KMS Service for encryption/decryption with rotation support
export class KMSService {
  private client: KMSClient;
  private keyAlias: string;

  constructor() {
    this.client = getKMSClient();
    this.keyAlias = kmsConfig.keyAlias;
  }

  async encrypt(plaintext: string): Promise<string> {
    const startTime = Date.now();

    try {
      const command = new EncryptCommand({
        KeyId: this.keyAlias, // Always use alias for rotation support
        Plaintext: Buffer.from(plaintext, 'utf8')
      });
      
      const result = await this.client.send(command);
      const encryptedData = Buffer.from(result.CiphertextBlob!).toString('base64');

      await this.recordMetric('KMS.Encrypt.Duration', Date.now() - startTime);
      await this.recordMetric('KMS.Encrypt.Success', 1);

      return encryptedData;
    } catch (error) {
      await this.recordMetric('KMS.Encrypt.Error', 1);
      console.error('KMS encryption failed:', error);
      throw new Error('Encryption operation failed');
    }
  }

  async decrypt(ciphertextBlob: string): Promise<string> {
    const startTime = Date.now();

    try {
      const command = new DecryptCommand({
        CiphertextBlob: Buffer.from(ciphertextBlob, 'base64')
        // Note: No KeyId needed for decryption - KMS automatically uses the correct key
      });
      
      const result = await this.client.send(command);
      const decryptedData = Buffer.from(result.Plaintext!).toString('utf8');

      await this.recordMetric('KMS.Decrypt.Duration', Date.now() - startTime);
      await this.recordMetric('KMS.Decrypt.Success', 1);

      return decryptedData;
    } catch (error) {
      await this.recordMetric('KMS.Decrypt.Error', 1);
      console.error('KMS decryption failed:', error);
      throw new Error('Decryption operation failed');
    }
  }

  async getKeyInfo(): Promise<any> {
    const startTime = Date.now();

    try {
      const command = new DescribeKeyCommand({
        KeyId: this.keyAlias
      });
      
      const result = await this.client.send(command);

      await this.recordMetric('KMS.DescribeKey.Duration', Date.now() - startTime);
      await this.recordMetric('KMS.DescribeKey.Success', 1);

      return result;
    } catch (error) {
      await this.recordMetric('KMS.DescribeKey.Error', 1);
      console.error('Failed to get key info:', error);
      throw error;
    }
  }

  async validateKeyRotation(): Promise<boolean> {
    try {
      const keyInfo = await this.getKeyInfo();
      const keyRotationEnabled = keyInfo.KeyMetadata?.KeyRotationStatus === 'Enabled';
      
      await this.recordMetric('KMS.RotationStatus', keyRotationEnabled ? 1 : 0);
      
      if (!keyRotationEnabled) {
        console.warn('KMS key rotation is not enabled for:', this.keyAlias);
      }
      
      return keyRotationEnabled;
    } catch (error) {
      console.error('Failed to validate key rotation:', error);
      return false;
    }
  }

  private async recordMetric(metricName: string, value: number): Promise<void> {
    if (!ENABLE_METRICS) return;

    try {
      const cloudWatchClient = getCloudWatchClient();
      await cloudWatchClient.send(
        new PutMetricDataCommand({
          Namespace: 'GitHubLinkBuddy/Application',
          MetricData: [
            {
              MetricName: metricName,
              Value: value,
              Unit: metricName.includes('Duration') ? 'Milliseconds' : 'Count',
              Dimensions: [
                {
                  Name: 'Environment',
                  Value: IS_PRODUCTION ? 'production' : 'development',
                },
                { Name: 'Service', Value: 'KMS' },
                { Name: 'KeyAlias', Value: this.keyAlias },
              ],
              Timestamp: new Date(),
            },
          ],
        })
      );
    } catch (error) {
      console.warn('Failed to record CloudWatch metric:', error);
    }
  }
}

// Application metrics service
export class MetricsService {
  private client: CloudWatchClient;
  private batchBuffer: any[] = [];
  private batchTimeout: NodeJS.Timeout | null = null;

  constructor() {
    this.client = getCloudWatchClient();
  }

  async recordMetric(
    metricName: string,
    value: number,
    unit: string = 'Count',
    dimensions: { [key: string]: string } = {}
  ): Promise<void> {
    if (!ENABLE_METRICS) return;

    const metric = {
      MetricName: metricName,
      Value: value,
      Unit: unit,
      Dimensions: Object.entries({
        Environment: IS_PRODUCTION ? 'production' : 'development',
        Application: 'github-link-buddy',
        ...dimensions,
      }).map(([Name, Value]) => ({ Name, Value })),
      Timestamp: new Date(),
    };

    this.batchBuffer.push(metric);

    // Batch metrics for efficiency
    if (this.batchBuffer.length >= 20 || !this.batchTimeout) {
      this.flushMetrics();
    } else if (!this.batchTimeout) {
      this.batchTimeout = setTimeout(() => this.flushMetrics(), 5000); // Flush after 5 seconds
    }
  }

  private async flushMetrics(): Promise<void> {
    if (this.batchBuffer.length === 0) return;

    try {
      const command = new PutMetricDataCommand({
        Namespace: 'GitHubLinkBuddy/Application',
        MetricData: this.batchBuffer.slice(0, 20), // CloudWatch limit is 20 metrics per request
      });

      await this.client.send(command);
      this.batchBuffer = this.batchBuffer.slice(20);

      if (this.batchTimeout) {
        clearTimeout(this.batchTimeout);
        this.batchTimeout = null;
      }

      // If there are more metrics, flush again
      if (this.batchBuffer.length > 0) {
        setTimeout(() => this.flushMetrics(), 100);
      }
    } catch (error) {
      console.warn('Failed to flush metrics to CloudWatch:', error);
    }
  }

  // Business metrics
  async recordUserAction(
    action: string,
    userId: string = 'anonymous'
  ): Promise<void> {
    await this.recordMetric(`User.${action}`, 1, 'Count', { UserId: userId });
  }

  async recordAPICall(
    endpoint: string,
    method: string,
    statusCode: number,
    duration: number
  ): Promise<void> {
    await this.recordMetric('API.Calls', 1, 'Count', {
      Endpoint: endpoint,
      Method: method,
      StatusCode: statusCode.toString(),
    });
    await this.recordMetric('API.Duration', duration, 'Milliseconds', {
      Endpoint: endpoint,
      Method: method,
    });
  }

  async recordError(
    errorType: string,
    context: string = 'unknown'
  ): Promise<void> {
    await this.recordMetric('Application.Errors', 1, 'Count', {
      ErrorType: errorType,
      Context: context,
    });
  }
}

// Singleton instances for services
export const dynamoDBService = new DynamoDBService();
export const s3Service = new S3Service();
export const secretsManagerService = new SecretsManagerService();
export const kmsService = new KMSService();
export const metricsService = new MetricsService();

// Health check function for ALB/API Gateway
export const healthCheck = async (): Promise<{
  status: string;
  timestamp: string;
  services: any;
}> => {
  const services = {
    dynamodb: 'unknown',
    s3: 'unknown',
    secretsManager: 'unknown',
    cloudwatch: 'unknown',
  };

  try {
    // Test DynamoDB connection
    await getDynamoDBClient().send(
      new QueryCommand({
        TableName: appConfig.aws.dynamoDbTable,
        KeyConditionExpression: 'id = :id',
        ExpressionAttributeValues: { ':id': 'health-check' },
        Limit: 1,
      })
    );
    services.dynamodb = 'healthy';
  } catch (error) {
    services.dynamodb = 'unhealthy';
  }

  try {
    // Test CloudWatch (metrics service)
    await metricsService.recordMetric('HealthCheck.Status', 1);
    services.cloudwatch = 'healthy';
  } catch (error) {
    services.cloudwatch = 'unhealthy';
  }

  return {
    status: Object.values(services).every(status => status === 'healthy')
      ? 'healthy'
      : 'degraded',
    timestamp: new Date().toISOString(),
    services,
  };
};

export default {
  appConfig,
  kmsConfig,
  dynamoDBService,
  s3Service,
  secretsManagerService,
  kmsService,
  metricsService,
  healthCheck,
};
